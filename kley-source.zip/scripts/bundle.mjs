// Собирает папку deploy/ — её содержимое загружают в корень сервера (/home/container).
import fs from 'node:fs';
import path from 'node:path';

const out = 'deploy';
for (const p of ['.next/standalone', '.next/static']) {
  if (!fs.existsSync(p)) {
    console.error(`Нет ${p}. Сначала выполни: npm run build`);
    process.exit(1);
  }
}
fs.rmSync(out, { recursive: true, force: true });
const cp = (from, to = from) =>
  fs.existsSync(from) && fs.cpSync(from, path.join(out, to), { recursive: true });

fs.cpSync('.next/standalone', out, { recursive: true });
cp('.next/static', '.next/static');
cp('public');
cp('prisma');
// WASM-компилятор запросов Prisma (query_compiler_bg.wasm)
cp('node_modules/.prisma');

// На Wispbyte / Pterodactyl стартовая команда проверяет:
//   if [ -f /home/container/package.json ]; then npm install; fi; node /home/container/index.js
// Намеренно удаляем package.json в корне deploy/, чтобы панель НЕ запускала тяжёлый npm install (OOM).
fs.rmSync(path.join(out, 'package.json'), { force: true });
fs.rmSync(path.join(out, 'node_modules', 'typescript'), { recursive: true, force: true });
fs.rmSync(path.join(out, 'node_modules', '@img'), { recursive: true, force: true });
fs.rmSync(path.join(out, 'node_modules', 'sharp'), { recursive: true, force: true });

fs.copyFileSync('index.js', path.join(out, 'index.js'));
fs.copyFileSync('.env.example', path.join(out, '.env.example'));
cp('README.md');
if (fs.existsSync('.env')) fs.copyFileSync('.env', path.join(out, '.env'));

console.log('Готово: папка deploy/ собрана.');
