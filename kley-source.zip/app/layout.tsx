import type { Metadata, Viewport } from 'next';
import { GeistSans } from 'geist/font/sans';
import '@fontsource-variable/inter/index.css';
import '@fontsource-variable/jetbrains-mono/index.css';
import './globals.css';
import { IslandProvider } from '@/components/ui/island';
import { TelegramProvider } from '@/components/TelegramProvider';
import { NeuralBackground } from '@/components/NeuralBackground';

export const metadata: Metadata = {
  title: 'KleyAI',
  description: 'Опиши задачу — нейросеть напишет код и закоммитит в GitHub.',
  icons: { icon: '/icon.svg' },
};
export const viewport: Viewport = { width: 'device-width', initialScale: 1, viewportFit: 'cover', themeColor: '#06060d' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru" data-theme="dark" className={GeistSans.variable}>
      <body>
        <TelegramProvider>
          <IslandProvider>
            <NeuralBackground />
            {children}
          </IslandProvider>
        </TelegramProvider>
      </body>
    </html>
  );
}
