import { PrismaClient } from '@prisma/client';
import { PrismaPg } from '@prisma/adapter-pg';
import { Pool } from 'pg';

const g = globalThis as unknown as { prisma?: PrismaClient };

function createClient(): PrismaClient {
  const connectionString = process.env.DATABASE_URL ?? '';
  const needSsl = /sslmode=(require|prefer)/i.test(connectionString);
  const pool = new Pool({
    connectionString,
    max: 5,
    ...(needSsl ? { ssl: { rejectUnauthorized: false } } : {}),
  });
  const adapter = new PrismaPg(pool);
  return new PrismaClient({ adapter });
}

export const db: PrismaClient = new Proxy({} as PrismaClient, {
  get(_target, prop, receiver) {
    if (!g.prisma) {
      g.prisma = createClient();
    }
    const val = Reflect.get(g.prisma, prop, receiver);
    return typeof val === 'function' ? val.bind(g.prisma) : val;
  },
});
