const securityHeaders = [
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  {
    key: 'Content-Security-Policy',
    // Monaco грузится с cdn.jsdelivr.net (позже можно захостить локально). frame-ancestors: сайт + клиенты Telegram. Превью (этап 2) живёт в sandbox-iframe со своим CSP.
    value: [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdn.jsdelivr.net",
      "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net",
      "img-src 'self' data: blob: https://avatars.githubusercontent.com https://t.me",
      "font-src 'self' data: https://cdn.jsdelivr.net",
      "connect-src 'self' https://cdn.jsdelivr.net",
      "worker-src 'self' blob:",
      "frame-src 'self' blob:",
      "frame-ancestors 'self' https://web.telegram.org https://*.telegram.org",
      "base-uri 'self'",
      "form-action 'self'",
    ].join('; '),
  },
];
export default {
  output: 'standalone',
  reactStrictMode: true,
  // Сборка не должна падать из-за типов/линта на хостинге; проверяй локально: npm run typecheck
  typescript: { ignoreBuildErrors: true },
  eslint: { ignoreDuringBuilds: true },
  experimental: { webpackMemoryOptimizations: true },
  async headers() { return [{ source: '/(.*)', headers: securityHeaders }]; },
};
