# KleyAI

AI-платформа для кодинга: чат с Gemini → файлы → превью → коммит/PR в GitHub + Arena (Elo).
Работает как сайт и как Telegram Mini App.

Стек: Next.js 15 (App Router) · TypeScript strict · Tailwind (токены Tokens Studio) · Framer Motion · Prisma + PostgreSQL · @google/genai · Octokit · @telegram-apps/sdk.

## 1. Подготовка (один раз)

**Telegram (BotFather):** /newbot → токен в `TELEGRAM_BOT_TOKEN`. Затем /newapp (или Bot Settings → Configure Mini App) → URL = `APP_URL`.

**GitHub OAuth App:** Settings → Developer settings → OAuth Apps → New.
- Homepage URL: `APP_URL`
- Callback URL: `APP_URL/api/auth/github/callback`
- Client ID / Secret → `.env`. Права запрашиваются минимальные: `repo read:user`.

**Gemini:** ключ из https://aistudio.google.com/apikey → `GEMINI_API_KEY`.

**Секреты:** `openssl rand -base64 48` → `SESSION_SECRET`; `openssl rand -base64 32` → `TOKEN_ENC_KEY`.

## 2. База данных (PostgreSQL)

Строка подключения в `DATABASE_URL`. Создать таблицы — любым из способов:
- **Prisma (с компьютера, где есть доступ к БД):** `npx prisma migrate deploy`
- **Вручную:** выполнить `prisma/migrations/20260101000000_init/migration.sql` через psql/pgAdmin.

Проверка порта: `nc -zv HOST PORT`.

## 3. Запуск на хостинге без Docker (Wispbyte и подобные)

**Вариант А — прямой запуск через `index.js`:**
Распаковать архив в корень сервера (`/home/container`), заполнить `.env` (или переменные панели) и запустить сервер.
Команда панели `node /home/container/index.js` (или `node index.js`) сама подхватит `.env`, порт из `PORT` / `SERVER_PORT`, при первом старте сгенерирует токены, Prisma Client и выполнит `next build`, а при следующих рестартах сразу запустит готовый standalone-сервер.

**Вариант Б — локальная сборка (если на сервере совсем мало RAM):**
```
cp .env.example .env      # заполнить
npm install
npm run bundle            # build + папка deploy/
```
Загрузить **содержимое `deploy/`** в корень сервера (`/home/container`). Файл `.env` лежит рядом с `index.js` (его читает сам `index.js`, переменные панели приоритетнее).
Стартовая команда панели `node /home/container/index.js` работает как есть. В `deploy/` намеренно нет `package.json`: иначе `npm install` на сервере сотрёт готовый `node_modules`.
Порт берётся из `PORT` / `SERVER_PORT`.

Сборка на Windows/Mac подходит: движки Prisma для Linux (openssl 1.1 и 3.0) уже включены в `schema.prisma`.

## 4. Запуск на VPS с Docker
```
cp .env.example .env && docker compose up -d --build
```
(`docker-compose.yml` поднимет и PostgreSQL; `DATABASE_URL` тогда `postgresql://kley:kley@db:5432/kley`.)

## 5. Разработка
```
npm run dev          # генерирует токены -> app/tokens.css, запускает Next
npm run typecheck
npm run tokens       # design/tokens.json -> CSS-переменные
```

## Архитектура
- `design/tokens.json` — токены (Tokens Studio, темы dark/light, синхронизация с Figma через GitHub).
- `lib/` — gemini, github, telegram (HMAC initData), crypto (AES-256-GCM), session, elo, arena, parse-code, preview.
- `app/api/` — auth, chats (SSE-стрим), github, arena.
- `components/` — ui (button, tabs, select, island), chat, panel (код/превью/GitHub), arena, Workspace.

## Чек-лист безопасности
Секреты только в env · zod на каждом входе · токены GitHub шифруются · превью в `sandbox="allow-scripts"` без same-origin + CSP · прямой коммит в основную ветку запрещён · один голос на раунд Arena (unique battleId).

## Известные ограничения
- Monaco грузится с cdn.jsdelivr.net (разрешён в CSP).
- Код не прогонялся автоматически: перед выкладкой выполни `npm run typecheck`.
- Нет UI-переключателя светлой темы (токены для неё готовы).
