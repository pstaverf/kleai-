// Tokens Studio JSON -> app/tokens.css (CSS-переменные). Tailwind читает те же переменные.
import fs from 'node:fs';

const t = JSON.parse(fs.readFileSync('design/tokens.json', 'utf8'));

function flat(node, path = [], out = {}) {
  for (const [k, v] of Object.entries(node)) {
    if (v && typeof v === 'object' && 'value' in v) out[[...path, k].join('-')] = String(v.value);
    else if (v && typeof v === 'object') flat(v, [...path, k], out);
  }
  return out;
}
const block = (sel, map) =>
  `${sel} {\n${Object.entries(map).map(([k, v]) => `  --${k}: ${v};`).join('\n')}\n}\n`;

const css =
  '/* AUTO-GENERATED from design/tokens.json — не редактировать вручную */\n' +
  block(':root, [data-theme="dark"]', { ...flat(t.global), ...flat(t.dark) }) +
  block('[data-theme="light"]', flat(t.light));

fs.writeFileSync('app/tokens.css', css);
console.log('tokens.css generated');
