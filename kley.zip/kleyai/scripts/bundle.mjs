// Собирает папку deploy/ — её целиком загружают на хостинг. Запуск: npm run bundle
import fs from 'node:fs';
import path from 'node:path';

const out = 'deploy';
for (const p of ['.next/standalone', '.next/static']) {
  if (!fs.existsSync(p)) { console.error(`Нет ${p}. Сначала выполни: npm run build`); process.exit(1); }
}
fs.rmSync(out, { recursive: true, force: true });
const cp = (from, to = from) => fs.existsSync(from) && fs.cpSync(from, path.join(out, to), { recursive: true });

fs.cpSync('.next/standalone', out, { recursive: true });
cp('.next/static', '.next/static');
cp('public');
cp('prisma');
// движки Prisma на случай, если трассировка их не включила
cp('node_modules/.prisma');
cp('node_modules/@prisma/client');

// Панель запускает: [ -f package.json ] && npm install; node /home/container/index.js
// npm install удалил бы готовый node_modules (лишние пакеты) — поэтому package.json в deploy/ не кладём.
fs.rmSync(path.join(out, 'package.json'), { force: true });

fs.writeFileSync(path.join(out, 'index.js'), `// Точка входа для хостинга: node index.js
const fs = require('node:fs');
const path = require('node:path');

// Мини-загрузчик .env (без зависимостей): переменные из панели имеют приоритет
try {
  const raw = fs.readFileSync(path.join(__dirname, '.env'), 'utf8');
  for (const line of raw.split(/\\r?\\n/)) {
    const m = line.match(/^\\s*([A-Za-z_][A-Za-z0-9_]*)\\s*=\\s*(.*?)\\s*$/);
    if (!m || line.trim().startsWith('#')) continue;
    const v = m[2].replace(/^(["'])(.*)\\1$/, '$2');
    if (process.env[m[1]] === undefined) process.env[m[1]] = v;
  }
} catch { /* .env нет — берём переменные окружения панели */ }

process.env.NODE_ENV = 'production';
process.env.HOSTNAME = '0.0.0.0';
process.env.PORT = process.env.PORT || process.env.SERVER_PORT || '3000';
require('./server.js');
`);
if (fs.existsSync('.env')) fs.copyFileSync('.env', path.join(out, '.env'));
else fs.copyFileSync('.env.example', path.join(out, '.env'));
console.log('Готово: папка deploy/. Загрузи её СОДЕРЖИМОЕ в корень сервера (/home/container), проверь .env, запусти.');
