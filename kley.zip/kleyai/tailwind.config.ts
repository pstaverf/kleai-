import type { Config } from 'tailwindcss';

const v = (name: string) => `var(--${name})`;

export default {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  darkMode: ['selector', '[data-theme="dark"]'],
  theme: {
    extend: {
      colors: {
        bg: { base: v('color-bg-base'), raised: v('color-bg-raised'), overlay: v('color-bg-overlay') },
        fg: { DEFAULT: v('color-fg-default'), muted: v('color-fg-muted'), onAccent: v('color-fg-onAccent') },
        line: { subtle: v('color-border-subtle'), strong: v('color-border-strong') },
        accent: { DEFAULT: v('color-accent-primary'), alt: v('color-accent-secondary') },
        ok: v('color-state-success'),
        err: v('color-state-error'),
      },
      borderRadius: { sm: v('radius-sm'), md: v('radius-md'), lg: v('radius-lg'), pill: v('radius-pill') },
      boxShadow: { glow: v('shadow-glow'), raised: v('shadow-raised') },
      fontFamily: { display: [v('font-display')], ui: [v('font-ui')], mono: [v('font-mono')] },
      minHeight: { touch: v('size-touch') },
      minWidth: { touch: v('size-touch') },
      transitionTimingFunction: { kley: 'cubic-bezier(0.22, 1, 0.36, 1)' },
    },
  },
  plugins: [],
} satisfies Config;
