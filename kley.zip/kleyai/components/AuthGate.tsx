'use client';
import { useCallback, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Logo, LogoMark } from '@/components/Logo';
import { useIsland } from '@/components/ui/island';
import { getInitData, haptic } from '@/components/TelegramProvider';
import { Workspace } from '@/components/Workspace';
import type { Me } from '@/lib/types';

type State = { s: 'loading' } | { s: 'anon'; inTg: boolean } | { s: 'authed'; me: Me } | { s: 'error' };

export function AuthGate() {
  const [state, setState] = useState<State>({ s: 'loading' });
  const island = useIsland();

  const load = useCallback(async () => {
    try {
      let me = (await (await fetch('/api/auth/me')).json()).user as Me | null;
      if (!me) {
        const initData = await getInitData();
        if (initData) {
          island.show({ state: 'thinking', label: 'Входим через Telegram…' });
          const r = await fetch('/api/auth/telegram', {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ initData }),
          });
          island.hide();
          if (r.ok) { haptic('success'); me = (await (await fetch('/api/auth/me')).json()).user; }
          else island.show({ state: 'error', label: 'Не удалось проверить Telegram-подпись' }, 4000);
        }
        if (!me) return setState({ s: 'anon', inTg: !!initData });
      }
      setState({ s: 'authed', me });
    } catch {
      setState({ s: 'error' });
    }
  }, [island]);

  useEffect(() => { void load(); }, [load]);

  if (state.s === 'loading')
    return (
      <main className="grid min-h-dvh place-items-center" aria-busy>
        <LogoMark size={56} animated />
      </main>
    );

  if (state.s === 'error')
    return (
      <main className="grid min-h-dvh place-items-center p-6 text-center">
        <div className="space-y-4">
          <p role="alert" className="text-err">Связь с сетью потеряна.</p>
          <Button onClick={() => { setState({ s: 'loading' }); void load(); }}>Повторить</Button>
        </div>
      </main>
    );

  if (state.s === 'anon')
    return (
      <main className="mx-auto flex min-h-dvh max-w-md flex-col items-center justify-center gap-8 p-6 text-center">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ type: 'spring', stiffness: 200, damping: 22 }}>
          <Logo size={44} />
        </motion.div>
        <h1 className="font-display text-4xl font-semibold leading-tight tracking-tight">
          Опиши задачу.<br /><span className="text-accent">Сеть напишет код.</span>
        </h1>
        <p className="text-fg-muted">Gemini пишет, KleyAI коммитит в твой GitHub.</p>
        <Button className="w-full" onClick={() => { location.href = '/api/auth/github'; }}>
          Войти через GitHub
        </Button>
        {state.inTg && <p role="alert" className="text-sm text-err">Telegram-вход не прошёл. Войди через GitHub.</p>}
      </main>
    );

  return <Workspace me={state.me} />;
}
