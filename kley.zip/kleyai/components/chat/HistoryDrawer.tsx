'use client';
import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import type { ChatSummary } from '@/lib/types';

export function HistoryDrawer({ open, chats, error, activeId, onClose, onPick, onNew, onDelete, onRetry }: {
  open: boolean; chats: ChatSummary[] | null; error: boolean; activeId: string | null;
  onClose: () => void; onPick: (id: string) => void; onNew: () => void; onDelete: (id: string) => void; onRetry: () => void;
}) {
  const [armed, setArmed] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    addEventListener('keydown', h);
    return () => removeEventListener('keydown', h);
  }, [open, onClose]);

  useEffect(() => { if (!armed) return; const t = setTimeout(() => setArmed(null), 3000); return () => clearTimeout(t); }, [armed]);

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.button
            key="bd" aria-label="Закрыть историю" type="button" onClick={onClose}
            className="fixed inset-0 z-40" style={{ background: 'rgba(3,3,10,0.7)' }}
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          />
          <motion.aside
            key="dr" role="dialog" aria-modal="true" aria-label="История чатов"
            className="fixed inset-y-0 left-0 z-40 flex w-[min(86vw,340px)] flex-col gap-3 border-r border-line-strong bg-bg-raised p-3 pt-[max(env(safe-area-inset-top),12px)] shadow-raised"
            initial={{ x: '-100%' }} animate={{ x: 0 }} exit={{ x: '-100%' }}
            transition={{ type: 'spring', stiffness: 380, damping: 36 }}
          >
            <Button onClick={() => { onNew(); onClose(); }}>+ Новый чат</Button>
            <div className="min-h-0 flex-1 space-y-1 overflow-y-auto">
              {error ? (
                <div role="alert" className="space-y-3 p-2 text-sm text-err">
                  <p>Не удалось загрузить историю.</p><Button variant="ghost" onClick={onRetry}>Повторить</Button>
                </div>
              ) : chats === null ? (
                [0, 1, 2, 3].map((i) => <div key={i} className="skeleton h-11" />)
              ) : chats.length === 0 ? (
                <p className="p-2 text-sm text-fg-muted">История пуста. Начни первый чат.</p>
              ) : (
                chats.map((c) => (
                  <div key={c.id} className={`flex items-center rounded-md border ${c.id === activeId ? 'border-accent' : 'border-transparent'} hover:bg-bg-overlay`}>
                    <button type="button" onClick={() => { onPick(c.id); onClose(); }} className="min-h-touch min-w-0 flex-1 truncate px-3 text-left text-sm">
                      {c.title}
                    </button>
                    <button type="button" onClick={() => (armed === c.id ? (setArmed(null), onDelete(c.id)) : setArmed(c.id))}
                      aria-label={armed === c.id ? 'Подтвердить удаление' : `Удалить чат ${c.title}`}
                      className={`min-h-touch min-w-touch px-2 text-xs ${armed === c.id ? 'text-err' : 'text-fg-muted hover:text-fg'}`}>
                      {armed === c.id ? 'Точно?' : '✕'}
                    </button>
                  </div>
                ))
              )}
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
