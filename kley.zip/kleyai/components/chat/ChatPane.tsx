'use client';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Select } from '@/components/ui/select';
import { MessageView } from './MessageView';
import { StreamPulse } from './StreamPulse';
import { MODELS, type ModelId } from '@/lib/models';
import type { Msg } from '@/lib/types';

const SUGGESTIONS = ['Лендинг для кофейни, тёмная тема', 'Змейка на canvas с счётом', 'Todo-приложение с фильтрами'];

export function ChatPane({ messages, loading, streaming, error, model, onModel, onSend, onStop, onOpenFile }: {
  messages: Msg[]; loading: boolean; streaming: boolean; error: string | null;
  model: ModelId; onModel: (m: ModelId) => void;
  onSend: (t: string) => void; onStop: () => void; onOpenFile: (p: string) => void;
}) {
  const [text, setText] = useState('');
  const taRef = useRef<HTMLTextAreaElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const stick = useRef(true);

  useLayoutEffect(() => {
    const t = taRef.current; if (!t) return;
    t.style.height = 'auto';
    t.style.height = `${Math.min(t.scrollHeight, 160)}px`;
  }, [text]);

  useEffect(() => {
    const el = scrollRef.current;
    if (el && stick.current) el.scrollTop = el.scrollHeight;
  }, [messages]);

  const submit = () => {
    const v = text.trim();
    if (!v || streaming) return;
    stick.current = true;
    setText('');
    onSend(v);
  };

  const coarse = typeof matchMedia !== 'undefined' && matchMedia('(pointer: coarse)').matches;

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div
        ref={scrollRef}
        onScroll={(e) => { const el = e.currentTarget; stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 120; }}
        className="min-h-0 flex-1 space-y-5 overflow-y-auto px-1 py-4"
        role="log" aria-live="polite" aria-busy={streaming}
      >
        {loading ? (
          <div className="space-y-3"><div className="skeleton ml-auto h-12 w-2/3" /><div className="skeleton h-24 w-full" /></div>
        ) : messages.length === 0 ? (
          <div className="grid h-full place-items-center text-center">
            <div className="space-y-4">
              <p className="font-display text-2xl">Что строим?</p>
              <p className="text-sm text-fg-muted">Опиши задачу — получишь файлы, предпросмотр и коммит.</p>
              <div className="flex flex-wrap justify-center gap-2">
                {SUGGESTIONS.map((s) => (
                  <button key={s} type="button" onClick={() => { setText(s); taRef.current?.focus(); }}
                    className="min-h-touch rounded-pill border border-line-subtle bg-bg-raised px-4 text-sm text-fg-muted transition-colors hover:border-accent hover:text-fg">
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          messages.map((m) => (
            <MessageView key={m.id} role={m.role} content={m.content} pending={streaming && m.id === 'pending'} onOpenFile={onOpenFile} />
          ))
        )}
        {error && (
          <div role="alert" className="rounded-md border border-err bg-bg-raised px-4 py-3 text-sm text-err">{error}</div>
        )}
      </div>

      {streaming && <StreamPulse />}

      <div className="space-y-2 rounded-lg border border-line-strong bg-bg-raised p-2 shadow-raised">
        <label className="sr-only" htmlFor="composer">Сообщение</label>
        <textarea
          id="composer" ref={taRef} value={text} rows={1} maxLength={20000}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey && !coarse) { e.preventDefault(); submit(); } }}
          placeholder="Опиши, что нужно сделать…"
          className="block max-h-40 w-full resize-none bg-transparent px-2 py-2 text-[15px] text-fg placeholder:text-fg-muted focus:outline-none"
        />
        <div className="flex items-center gap-2">
          <Select label="Модель" value={model} onChange={(e) => onModel(e.target.value as ModelId)} className="min-w-0 flex-1" disabled={streaming}>
            {MODELS.map((m) => <option key={m.id} value={m.id}>{m.label} — {m.hint}</option>)}
          </Select>
          {streaming ? (
            <Button variant="danger" onClick={onStop} aria-label="Остановить генерацию">Стоп</Button>
          ) : (
            <Button onClick={submit} disabled={!text.trim()} aria-label="Отправить">Отправить</Button>
          )}
        </div>
      </div>
    </div>
  );
}
