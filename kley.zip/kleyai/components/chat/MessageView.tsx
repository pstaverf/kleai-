'use client';
import { memo, useState } from 'react';
import { parseSegments, type Segment } from '@/lib/parse-code';
import { haptic } from '@/components/TelegramProvider';

function CodeBlock({ seg, onOpenFile }: { seg: Extract<Segment, { type: 'code' }>; onOpenFile: (p: string) => void }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try { await navigator.clipboard.writeText(seg.code); setCopied(true); haptic('light'); setTimeout(() => setCopied(false), 1400); } catch { /* нет доступа к буферу */ }
  };
  return (
    <figure className="overflow-hidden rounded-md border border-line-subtle bg-bg-base">
      <figcaption className="flex items-center justify-between gap-2 border-b border-line-subtle bg-bg-overlay px-3">
        {seg.file ? (
          <button type="button" onClick={() => onOpenFile(seg.file!)} className="min-h-touch truncate font-mono text-xs text-accent hover:underline">
            {seg.file}
          </button>
        ) : (
          <span className="font-mono text-xs text-fg-muted">{seg.lang || 'code'}</span>
        )}
        <button type="button" onClick={copy} className="min-h-touch px-2 text-xs text-fg-muted hover:text-fg" aria-live="polite">
          {copied ? 'Скопировано' : 'Копировать'}
        </button>
      </figcaption>
      <pre className="max-h-80 overflow-auto p-3 font-mono text-[13px] leading-relaxed"><code>{seg.code}{!seg.closed && <span className="ml-0.5 inline-block h-4 w-1.5 animate-pulse bg-accent align-middle" />}</code></pre>
    </figure>
  );
}

export const MessageView = memo(function MessageView({ role, content, pending, onOpenFile }: {
  role: 'user' | 'model'; content: string; pending?: boolean; onOpenFile: (p: string) => void;
}) {
  if (role === 'user')
    return <div className="ml-auto max-w-[88%] whitespace-pre-wrap break-words rounded-lg border border-line-strong bg-bg-overlay px-4 py-3 text-[15px]">{content}</div>;

  const segs = parseSegments(content);
  return (
    <div className="max-w-full space-y-3 text-[15px] leading-relaxed">
      {pending && !content && (
        <div className="space-y-2" aria-label="Gemini думает">
          <div className="skeleton h-4 w-3/4" /><div className="skeleton h-4 w-1/2" />
        </div>
      )}
      {segs.map((s, i) =>
        s.type === 'text'
          ? s.text.trim() ? <p key={i} className="whitespace-pre-wrap break-words">{s.text.trim()}</p> : null
          : <CodeBlock key={i} seg={s} onOpenFile={onOpenFile} />,
      )}
    </div>
  );
});
