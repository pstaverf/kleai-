'use client';
import { motion, useReducedMotion } from 'framer-motion';

/** Светящиеся импульсы от поля ввода к ответу вместо спиннера. */
export function StreamPulse() {
  const reduce = useReducedMotion();
  return (
    <div aria-hidden className="relative mx-auto h-7 w-24 overflow-hidden">
      {[0, 1, 2, 3].map((i) => (
        <motion.span
          key={i}
          className="absolute bottom-0 size-1.5 rounded-full bg-accent shadow-glow"
          style={{ left: `${12 + i * 22}%` }}
          initial={{ opacity: reduce ? 1 : 0 }}
          animate={reduce ? undefined : { y: [0, -26], opacity: [0, 1, 0] }}
          transition={{ duration: 1.1, repeat: Infinity, delay: i * 0.22, ease: 'easeOut' }}
        />
      ))}
    </div>
  );
}
