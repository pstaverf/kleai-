'use client';
import type { SelectHTMLAttributes } from 'react';

/** Нативный select (максимальная доступность и удобство на мобильных) в стиле KleyAI. */
export function Select({ label, className = '', children, ...rest }: SelectHTMLAttributes<HTMLSelectElement> & { label: string }) {
  return (
    <label className={`relative block ${className}`}>
      <span className="sr-only">{label}</span>
      <select
        {...rest}
        className="min-h-touch w-full appearance-none truncate rounded-md border border-line-subtle bg-bg-raised py-2 pl-3 pr-9 text-sm text-fg transition-colors hover:border-line-strong disabled:opacity-50"
      >
        {children}
      </select>
      <svg aria-hidden className="pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 text-fg-muted" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
        <path d="m4 6 4 4 4-4" />
      </svg>
    </label>
  );
}
