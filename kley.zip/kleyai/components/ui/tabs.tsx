'use client';
import { motion } from 'framer-motion';
import { haptic } from '@/components/TelegramProvider';

interface Item<T extends string> { id: T; label: string }

/** Табы с shared-layout подчёркиванием (пружина). */
export function Tabs<T extends string>({ value, onChange, items, layoutId, label }: {
  value: T; onChange: (v: T) => void; items: Item<T>[]; layoutId: string; label: string;
}) {
  return (
    <div role="tablist" aria-label={label} className="flex gap-1 rounded-pill border border-line-subtle bg-bg-raised p-1">
      {items.map((it) => {
        const on = it.id === value;
        return (
          <button
            key={it.id} role="tab" aria-selected={on} type="button"
            onClick={() => { haptic('light'); onChange(it.id); }}
            className={`relative min-h-touch flex-1 rounded-pill px-4 text-sm font-medium transition-colors ${on ? 'text-fg-onAccent' : 'text-fg-muted hover:text-fg'}`}
          >
            {on && (
              <motion.span layoutId={layoutId} className="absolute inset-0 rounded-pill bg-accent shadow-glow"
                transition={{ type: 'spring', stiffness: 420, damping: 32 }} />
            )}
            <span className="relative">{it.label}</span>
          </button>
        );
      })}
    </div>
  );
}
