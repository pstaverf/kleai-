'use client';
import { motion, type HTMLMotionProps } from 'framer-motion';
import { forwardRef } from 'react';
import { haptic } from '@/components/TelegramProvider';

type Variant = 'primary' | 'ghost' | 'danger';

const styles: Record<Variant, string> = {
  primary: 'bg-accent text-fg-onAccent shadow-glow hover:brightness-110',
  ghost: 'bg-bg-raised text-fg border border-line-subtle hover:border-line-strong',
  danger: 'bg-bg-raised text-err border border-line-strong hover:border-err',
};

interface Props extends Omit<HTMLMotionProps<'button'>, 'ref'> {
  variant?: Variant;
  loading?: boolean;
}

export const Button = forwardRef<HTMLButtonElement, Props>(function Button(
  { variant = 'primary', loading, disabled, className = '', children, onClick, ...rest },
  ref,
) {
  return (
    <motion.button
      ref={ref}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.96 }}
      transition={{ type: 'spring', stiffness: 520, damping: 28 }}
      disabled={disabled || loading}
      aria-busy={loading}
      onClick={(e) => { haptic('light'); onClick?.(e); }}
      className={`inline-flex min-h-touch items-center justify-center gap-2 rounded-pill px-6 font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-50 ${styles[variant]} ${className}`}
      {...rest}
    >
      {loading ? <span className="size-4 animate-spin rounded-full border-2 border-current border-t-transparent" aria-hidden /> : null}
      {children}
    </motion.button>
  );
});
