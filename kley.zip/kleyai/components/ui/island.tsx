'use client';
import { AnimatePresence, motion } from 'framer-motion';
import { createContext, useCallback, useContext, useRef, useState, type ReactNode } from 'react';

export type IslandState = 'thinking' | 'files' | 'commit' | 'error' | 'success';
interface Item { state: IslandState; label: string }
interface Ctx { show: (i: Item, ttl?: number) => void; hide: () => void }

const IslandCtx = createContext<Ctx>({ show: () => {}, hide: () => {} });
export const useIsland = () => useContext(IslandCtx);

const dot: Record<IslandState, string> = {
  thinking: 'bg-accent', files: 'bg-accent', commit: 'bg-accent-alt', error: 'bg-err', success: 'bg-ok',
};

/** Dynamic-Island-плашка: компактный живой статус вверху экрана. */
export function IslandProvider({ children }: { children: ReactNode }) {
  const [item, setItem] = useState<Item | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout>>(undefined);

  const hide = useCallback(() => setItem(null), []);
  const show = useCallback((i: Item, ttl?: number) => {
    clearTimeout(timer.current);
    setItem(i);
    if (ttl) timer.current = setTimeout(() => setItem(null), ttl);
  }, []);

  return (
    <IslandCtx.Provider value={{ show, hide }}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 top-0 z-50 flex justify-center pt-[max(env(safe-area-inset-top),12px)]">
        <AnimatePresence>
          {item && (
            <motion.div
              key={item.state}
              role="status"
              aria-live="polite"
              layout
              initial={{ y: -40, scale: 0.6, opacity: 0 }}
              animate={{ y: 0, scale: 1, opacity: 1 }}
              exit={{ y: -40, scale: 0.6, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 420, damping: 30 }}
              className="pointer-events-auto flex items-center gap-3 rounded-pill border border-line-strong bg-bg-overlay px-4 py-2 text-sm shadow-raised"
            >
              <motion.span
                className={`size-2.5 rounded-full ${dot[item.state]}`}
                animate={{ scale: [1, 1.5, 1], opacity: [1, 0.5, 1] }}
                transition={{ duration: 1.2, repeat: Infinity }}
              />
              <span>{item.label}</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </IslandCtx.Provider>
  );
}
