'use client';
import { motion, useReducedMotion } from 'framer-motion';

/** Абстрактный нейрон с лучами + wordmark. animated=true — loader. */
export function LogoMark({ size = 32, animated = false }: { size?: number; animated?: boolean }) {
  const reduce = useReducedMotion();
  const rays = Array.from({ length: 6 }, (_, i) => (i * Math.PI * 2) / 6 - Math.PI / 2);
  return (
    <svg width={size} height={size} viewBox="-20 -20 40 40" role="img" aria-label="KleyAI" fill="none">
      {rays.map((a, i) => {
        const x = Math.cos(a) * 15, y = Math.sin(a) * 15;
        return (
          <g key={i}>
            <line x1={Math.cos(a) * 6} y1={Math.sin(a) * 6} x2={x} y2={y} stroke="var(--color-accent-primary)" strokeWidth="1.4" strokeLinecap="round" opacity="0.7" />
            <motion.circle
              cx={x} cy={y} r={i === 2 ? 2.4 : 1.8}
              fill={i === 2 ? 'var(--color-accent-secondary)' : 'var(--color-accent-primary)'}
              animate={animated && !reduce ? { opacity: [0.3, 1, 0.3] } : undefined}
              transition={{ duration: 1.4, repeat: Infinity, delay: i * 0.18 }}
            />
          </g>
        );
      })}
      <circle r="6" fill="var(--color-accent-primary)" style={{ filter: 'drop-shadow(0 0 6px var(--color-accent-primary))' }} />
    </svg>
  );
}

export function Logo({ size = 28 }: { size?: number }) {
  return (
    <span className="inline-flex items-center gap-2">
      <LogoMark size={size} />
      <span className="font-display text-xl font-semibold tracking-tight">
        Kley<span className="text-accent">AI</span>
      </span>
    </span>
  );
}
