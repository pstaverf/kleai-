'use client';
import dynamic from 'next/dynamic';
import type { Monaco } from '@monaco-editor/react';
import { FileTree } from './FileTree';
import { langOf } from '@/lib/parse-code';
import type { GenFile } from '@/lib/types';

const Editor = dynamic(() => import('@monaco-editor/react').then((m) => m.default), {
  ssr: false,
  loading: () => <div className="skeleton size-full" aria-label="Загрузка редактора" />,
});

function defineTheme(monaco: Monaco) {
  monaco.editor.defineTheme('kley', {
    base: 'vs-dark', inherit: true,
    rules: [
      { token: 'comment', foreground: '6b7099', fontStyle: 'italic' },
      { token: 'keyword', foreground: 'ff5c8a' },
      { token: 'string', foreground: '5dffa8' },
      { token: 'number', foreground: '2ef2e0' },
      { token: 'type', foreground: '9aa4ff' },
    ],
    colors: {
      'editor.background': '#06060d',
      'editor.foreground': '#e8ecff',
      'editorLineNumber.foreground': '#33366a',
      'editorLineNumber.activeForeground': '#2ef2e0',
      'editor.selectionBackground': '#2ef2e033',
      'editor.lineHighlightBackground': '#0c0c1a',
      'editorCursor.foreground': '#2ef2e0',
      'editorIndentGuide.background1': '#14142b',
      'scrollbarSlider.background': '#33366a66',
    },
  });
}

export function CodePanel({ files, selected, onSelect, onEdit }: {
  files: GenFile[]; selected: string | null; onSelect: (p: string) => void; onEdit: (p: string, v: string) => void;
}) {
  if (files.length === 0)
    return (
      <div className="grid h-full place-items-center p-6 text-center text-sm text-fg-muted">
        <p>Файлов пока нет. Попроси Gemini написать код — файлы появятся здесь.</p>
      </div>
    );
  const file = files.find((f) => f.path === selected) ?? files[0]!;
  return (
    <div className="flex h-full min-h-0 flex-col lg:flex-row">
      <div className="max-h-40 shrink-0 overflow-y-auto border-b border-line-subtle p-2 lg:max-h-none lg:w-52 lg:border-b-0 lg:border-r">
        <FileTree paths={files.map((f) => f.path)} selected={file.path} onSelect={onSelect} />
      </div>
      <div className="min-h-0 flex-1">
        <Editor
          height="100%" path={file.path} language={langOf(file.path)} value={file.content} theme="kley"
          beforeMount={defineTheme}
          onChange={(v) => onEdit(file.path, v ?? '')}
          options={{ minimap: { enabled: false }, fontFamily: "'JetBrains Mono', ui-monospace, monospace", fontSize: 13, scrollBeyondLastLine: false, padding: { top: 12 }, automaticLayout: true, wordWrap: 'on' }}
        />
      </div>
    </div>
  );
}
