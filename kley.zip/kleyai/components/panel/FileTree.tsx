'use client';
import { useMemo, useState } from 'react';

interface Node { name: string; path: string; children: Node[]; file: boolean }

function build(paths: string[]): Node[] {
  const root: Node = { name: '', path: '', children: [], file: false };
  for (const p of paths) {
    let cur = root;
    p.split('/').forEach((part, i, arr) => {
      const path = arr.slice(0, i + 1).join('/');
      let n = cur.children.find((c) => c.name === part);
      if (!n) { n = { name: part, path, children: [], file: i === arr.length - 1 }; cur.children.push(n); }
      cur = n;
    });
  }
  const sort = (n: Node) => { n.children.sort((a, b) => Number(a.file) - Number(b.file) || a.name.localeCompare(b.name)); n.children.forEach(sort); };
  sort(root);
  return root.children;
}

export function FileTree({ paths, selected, onSelect }: { paths: string[]; selected: string | null; onSelect: (p: string) => void }) {
  const tree = useMemo(() => build(paths), [paths]);
  const [closed, setClosed] = useState<Set<string>>(new Set());
  const toggle = (p: string) => setClosed((s) => { const n = new Set(s); n.has(p) ? n.delete(p) : n.add(p); return n; });

  const render = (nodes: Node[], depth: number) => (
    <ul role={depth === 0 ? 'tree' : 'group'} className="space-y-0.5">
      {nodes.map((n) => (
        <li key={n.path} role="treeitem" aria-expanded={n.file ? undefined : !closed.has(n.path)} aria-selected={n.file ? n.path === selected : undefined}>
          <button
            type="button"
            onClick={() => (n.file ? onSelect(n.path) : toggle(n.path))}
            style={{ paddingLeft: 8 + depth * 14 }}
            className={`flex min-h-touch w-full items-center gap-2 truncate rounded-sm pr-2 text-left font-mono text-xs transition-colors lg:min-h-8 ${n.path === selected ? 'bg-bg-overlay text-accent' : 'text-fg-muted hover:text-fg'}`}
          >
            <span aria-hidden>{n.file ? '·' : closed.has(n.path) ? '▸' : '▾'}</span>
            <span className="truncate">{n.name}</span>
          </button>
          {!n.file && !closed.has(n.path) && render(n.children, depth + 1)}
        </li>
      ))}
    </ul>
  );
  return <nav aria-label="Файлы проекта">{render(tree, 0)}</nav>;
}
