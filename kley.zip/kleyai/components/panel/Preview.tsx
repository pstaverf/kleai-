'use client';
import { useMemo, useState } from 'react';
import { Button } from '@/components/ui/button';
import { buildPreview } from '@/lib/preview';
import type { GenFile } from '@/lib/types';

export function Preview({ files }: { files: GenFile[] }) {
  const doc = useMemo(() => buildPreview(files), [files]);
  const [key, setKey] = useState(0);
  if (!doc)
    return (
      <div className="grid h-full place-items-center p-6 text-center text-sm text-fg-muted">
        <p>Нечего показывать: для предпросмотра нужен файл index.html.</p>
      </div>
    );
  return (
    <div className="flex h-full min-h-0 flex-col gap-2 p-2">
      <div className="flex justify-end"><Button variant="ghost" className="min-h-touch px-4 text-sm" onClick={() => setKey((k) => k + 1)}>Перезапустить</Button></div>
      {/* sandbox без allow-same-origin: код предпросмотра изолирован от сайта, токенов и cookie */}
      <iframe key={key} title="Предпросмотр" srcDoc={doc} sandbox="allow-scripts" referrerPolicy="no-referrer"
        className="min-h-0 w-full flex-1 rounded-md border border-line-subtle bg-white" />
    </div>
  );
}
