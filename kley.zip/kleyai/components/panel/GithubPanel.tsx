'use client';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Select } from '@/components/ui/select';
import { useIsland } from '@/components/ui/island';
import { haptic } from '@/components/TelegramProvider';
import { useTelegramMain } from '@/components/useTelegramButtons';
import { api } from '@/lib/client';
import type { GenFile, Me } from '@/lib/types';

interface Repo { fullName: string; defaultBranch: string; private: boolean }
const MAX_CTX = 20;
const input = 'min-h-touch w-full rounded-md border border-line-subtle bg-bg-base px-3 text-sm text-fg placeholder:text-fg-muted hover:border-line-strong';

export function GithubPanel({ me, repo, branch, onSelect, files, contextFiles, setContextFiles, tgActive }: {
  me: Me; repo: string | null; branch: string | null; onSelect: (r: string | null, b: string | null) => void;
  files: GenFile[]; contextFiles: string[]; setContextFiles: (f: string[]) => void; tgActive: boolean;
}) {
  const island = useIsland();
  const [repos, setRepos] = useState<Repo[] | null>(null);
  const [repoErr, setRepoErr] = useState<string | null>(null);
  const [branches, setBranches] = useState<string[]>([]);
  const [tree, setTree] = useState<string[] | null>(null);
  const [treeErr, setTreeErr] = useState<string | null>(null);
  const [filter, setFilter] = useState('');
  const [newBranch, setNewBranch] = useState('');
  const [msg, setMsg] = useState('');
  const [excluded, setExcluded] = useState<string[]>([]);
  const [busy, setBusy] = useState<null | 'commit' | 'branch' | 'pr'>(null);
  const [result, setResult] = useState<{ commit?: string; pr?: string; error?: string }>({});

  const loadRepos = useCallback(() => {
    setRepos(null); setRepoErr(null);
    api<{ repos: Repo[] }>('/api/github/repos').then((d) => setRepos(d.repos)).catch((e: Error) => setRepoErr(e.message));
  }, []);
  useEffect(() => { if (me.hasGithub) loadRepos(); }, [me.hasGithub, loadRepos]);

  const loadBranches = useCallback(async (r: string) => {
    const d = await api<{ branches: string[] }>(`/api/github/branches?repo=${encodeURIComponent(r)}`);
    setBranches(d.branches);
  }, []);
  useEffect(() => { if (repo) loadBranches(repo).catch(() => setBranches([])); else setBranches([]); }, [repo, loadBranches]);

  useEffect(() => {
    setTree(null); setTreeErr(null);
    if (!repo || !branch) return;
    let c = false;
    api<{ paths: string[] }>(`/api/github/tree?repo=${encodeURIComponent(repo)}&branch=${encodeURIComponent(branch)}`)
      .then((d) => !c && setTree(d.paths)).catch((e: Error) => !c && setTreeErr(e.message));
    return () => { c = true; };
  }, [repo, branch]);

  const defaultBranch = repos?.find((r) => r.fullName === repo)?.defaultBranch ?? null;
  const commitFilesList = files.filter((f) => !excluded.includes(f.path));
  const onDefault = !!branch && branch === defaultBranch;
  const canCommit = !!repo && !!branch && !onDefault && commitFilesList.length > 0 && !busy;
  const message = msg.trim() || `KleyAI: ${commitFilesList.length} файл(ов)`;

  const fail = (e: unknown) => {
    const m = e instanceof Error ? e.message : 'Ошибка';
    setResult({ error: m }); island.show({ state: 'error', label: m }, 5000); haptic('error');
  };

  const commit = async () => {
    if (!canCommit || !repo || !branch) return;
    setBusy('commit'); setResult({}); island.show({ state: 'commit', label: 'Коммитим в GitHub…' });
    try {
      const r = await api<{ url: string }>('/api/github/commit', { method: 'POST', json: { repo, branch, message, files: commitFilesList.map((f) => ({ path: f.path, content: f.content })) } });
      setResult({ commit: r.url }); island.show({ state: 'success', label: 'Коммит создан' }, 2200); haptic('success');
    } catch (e) { fail(e); } finally { setBusy(null); }
  };

  const makeBranch = async () => {
    if (!repo || !branch || !newBranch.trim()) return;
    setBusy('branch'); setResult({});
    try {
      const name = newBranch.trim();
      await api('/api/github/branch', { method: 'POST', json: { repo, from: branch, name } });
      await loadBranches(repo); onSelect(repo, name); setNewBranch(''); haptic('success');
    } catch (e) { fail(e); } finally { setBusy(null); }
  };

  const openPr = async () => {
    if (!repo || !branch || onDefault) return;
    setBusy('pr'); island.show({ state: 'commit', label: 'Открываем Pull Request…' });
    try {
      const r = await api<{ url: string }>('/api/github/pr', { method: 'POST', json: { repo, head: branch, title: message } });
      setResult((p) => ({ ...p, pr: r.url })); island.show({ state: 'success', label: 'Pull Request создан' }, 2200); haptic('success');
    } catch (e) { fail(e); } finally { setBusy(null); }
  };

  useTelegramMain(tgActive && files.length > 0 ? { text: 'Закоммитить', enabled: canCommit, loading: busy === 'commit' } : null, commit);

  const shown = useMemo(() => (tree ?? []).filter((p) => p.toLowerCase().includes(filter.toLowerCase())).slice(0, 200), [tree, filter]);
  const toggleCtx = (p: string) =>
    setContextFiles(contextFiles.includes(p) ? contextFiles.filter((x) => x !== p) : contextFiles.length < MAX_CTX ? [...contextFiles, p] : contextFiles);

  if (!me.hasGithub)
    return (
      <div className="grid h-full place-items-center p-6 text-center">
        <div className="space-y-4">
          <p className="text-sm text-fg-muted">Подключи GitHub, чтобы читать репозитории и коммитить результат.</p>
          <Button onClick={() => { location.href = '/api/auth/github'; }}>Подключить GitHub</Button>
        </div>
      </div>
    );

  return (
    <div className="h-full space-y-5 overflow-y-auto p-3">
      <section className="space-y-2" aria-label="Репозиторий">
        {repoErr ? (
          <div role="alert" className="space-y-2 text-sm text-err"><p>{repoErr}</p><Button variant="ghost" onClick={loadRepos}>Повторить</Button></div>
        ) : repos === null ? (
          <div className="skeleton h-11" />
        ) : repos.length === 0 ? (
          <p className="text-sm text-fg-muted">Нет репозиториев с правом записи.</p>
        ) : (
          <Select label="Репозиторий" value={repo ?? ''} onChange={(e) => {
            const r = repos.find((x) => x.fullName === e.target.value);
            setContextFiles([]); onSelect(r?.fullName ?? null, r?.defaultBranch ?? null);
          }}>
            <option value="">— без репозитория —</option>
            {repos.map((r) => <option key={r.fullName} value={r.fullName}>{r.fullName}{r.private ? ' 🔒' : ''}</option>)}
          </Select>
        )}
        {repo && (
          <Select label="Ветка" value={branch ?? ''} onChange={(e) => { setContextFiles([]); onSelect(repo, e.target.value); }}>
            {branches.map((b) => <option key={b} value={b}>{b}{b === defaultBranch ? ' (основная)' : ''}</option>)}
          </Select>
        )}
        {repo && branch && (
          <div className="flex gap-2">
            <input className={input} value={newBranch} onChange={(e) => setNewBranch(e.target.value)} placeholder="Новая ветка, напр. kley/feature" aria-label="Имя новой ветки" maxLength={100} />
            <Button variant="ghost" loading={busy === 'branch'} disabled={!/^[\w./-]+$/.test(newBranch.trim())} onClick={makeBranch}>Создать</Button>
          </div>
        )}
      </section>

      {repo && branch && (
        <section className="space-y-2" aria-label="Контекст из репозитория">
          <div className="flex items-baseline justify-between">
            <h3 className="font-display text-sm font-semibold">Контекст для Gemini</h3>
            <span className="text-xs text-fg-muted">{contextFiles.length}/{MAX_CTX}</span>
          </div>
          <input className={input} value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="Поиск файла…" aria-label="Поиск по файлам репозитория" />
          {treeErr ? <p role="alert" className="text-sm text-err">{treeErr}</p>
            : tree === null ? <div className="space-y-1"><div className="skeleton h-9" /><div className="skeleton h-9" /></div>
            : shown.length === 0 ? <p className="text-sm text-fg-muted">Файлы не найдены.</p>
            : (
              <ul className="max-h-56 overflow-y-auto rounded-md border border-line-subtle">
                {shown.map((p) => (
                  <li key={p}>
                    <label className="flex min-h-touch cursor-pointer items-center gap-3 px-3 text-left font-mono text-xs hover:bg-bg-overlay">
                      <input type="checkbox" className="size-5 accent-accent" checked={contextFiles.includes(p)} onChange={() => toggleCtx(p)} />
                      <span className="truncate">{p}</span>
                    </label>
                  </li>
                ))}
              </ul>
            )}
        </section>
      )}

      {repo && branch && (
        <section className="space-y-3" aria-label="Коммит и Pull Request">
          <h3 className="font-display text-sm font-semibold">Коммит</h3>
          {onDefault && <p role="alert" className="text-sm text-accent-alt">Это основная ветка — создай новую ветку, прямой коммит отключён.</p>}
          {files.length === 0 ? <p className="text-sm text-fg-muted">Нет сгенерированных файлов для коммита.</p> : (
            <ul>
              {files.map((f) => (
                <li key={f.path}>
                  <label className="flex min-h-touch cursor-pointer items-center gap-3 font-mono text-xs">
                    <input type="checkbox" className="size-5 accent-accent" checked={!excluded.includes(f.path)}
                      onChange={() => setExcluded((x) => (x.includes(f.path) ? x.filter((p) => p !== f.path) : [...x, f.path]))} />
                    <span className="truncate">{f.path}</span>
                  </label>
                </li>
              ))}
            </ul>
          )}
          <input className={input} value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="Сообщение коммита" aria-label="Сообщение коммита" maxLength={200} />
          <div className="flex gap-2">
            <Button className="flex-1" loading={busy === 'commit'} disabled={!canCommit} onClick={commit}>Закоммитить</Button>
            <Button className="flex-1" variant="ghost" loading={busy === 'pr'} disabled={!result.commit || onDefault || !!busy} onClick={openPr}>Pull Request</Button>
          </div>
          {result.error && <p role="alert" className="text-sm text-err">{result.error}</p>}
          {result.commit && <p className="text-sm"><a className="text-accent underline" href={result.commit} target="_blank" rel="noopener noreferrer">Коммит создан ↗</a></p>}
          {result.pr && <p className="text-sm"><a className="text-accent underline" href={result.pr} target="_blank" rel="noopener noreferrer">Pull Request ↗</a></p>}
        </section>
      )}
    </div>
  );
}
