'use client';
import { useState } from 'react';
import { Tabs } from '@/components/ui/tabs';
import { CodePanel } from './CodePanel';
import { Preview } from './Preview';
import { GithubPanel } from './GithubPanel';
import type { GenFile, Me } from '@/lib/types';

export type PanelTab = 'code' | 'preview' | 'github';

export function SidePanel({ tab, onTab, me, files, selected, onSelect, onEdit, repo, branch, onRepo, contextFiles, setContextFiles, tgActive }: {
  tab: PanelTab; onTab: (t: PanelTab) => void; me: Me; files: GenFile[];
  selected: string | null; onSelect: (p: string) => void; onEdit: (p: string, v: string) => void;
  repo: string | null; branch: string | null; onRepo: (r: string | null, b: string | null) => void;
  contextFiles: string[]; setContextFiles: (f: string[]) => void; tgActive: boolean;
}) {
  return (
    <div className="flex min-h-0 flex-1 flex-col gap-2">
      <Tabs<PanelTab> label="Панель" layoutId="panel-tab" value={tab} onChange={onTab}
        items={[{ id: 'code', label: 'Код' }, { id: 'preview', label: 'Превью' }, { id: 'github', label: 'GitHub' }]} />
      <div className="min-h-0 flex-1 overflow-hidden rounded-lg border border-line-subtle bg-bg-raised">
        <div className={tab === 'code' ? 'h-full' : 'hidden'}><CodePanel files={files} selected={selected} onSelect={onSelect} onEdit={onEdit} /></div>
        {tab === 'preview' && <Preview files={files} />}
        <div className={tab === 'github' ? 'h-full' : 'hidden'}>
          <GithubPanel me={me} repo={repo} branch={branch} onSelect={onRepo} files={files} contextFiles={contextFiles} setContextFiles={setContextFiles} tgActive={tgActive && tab === 'github'} />
        </div>
      </div>
    </div>
  );
}
