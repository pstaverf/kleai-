'use client';
import { useEffect, useRef, useState } from 'react';
import { animate, motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import type { ArenaRating } from '@/lib/types';

function Num({ value }: { value: number }) {
  const [shown, setShown] = useState(value);
  const prev = useRef(value);
  useEffect(() => {
    const c = animate(prev.current, value, { duration: 0.9, ease: 'easeOut', onUpdate: setShown });
    prev.current = value;
    return () => c.stop();
  }, [value]);
  return <>{Math.round(shown)}</>;
}

/** Elo как живая шкала: узлы моделей плавно (пружиной) смещаются после каждого голоса. */
export function EloScale({ ratings, error, deltas, onRetry }: {
  ratings: ArenaRating[] | null; error: boolean; deltas: Record<string, number> | null; onRetry: () => void;
}) {
  if (error)
    return (
      <div role="alert" className="flex items-center justify-between gap-3 rounded-lg border border-line-subtle bg-bg-raised p-4 text-sm text-err">
        <span>Не удалось загрузить рейтинг.</span><Button variant="ghost" onClick={onRetry}>Повторить</Button>
      </div>
    );
  if (!ratings) return <div className="skeleton h-28" aria-label="Загрузка рейтинга" />;

  const elos = ratings.map((r) => r.elo);
  let lo = Math.floor((Math.min(...elos) - 60) / 50) * 50;
  let hi = Math.ceil((Math.max(...elos) + 60) / 50) * 50;
  if (hi - lo < 200) { const c = (hi + lo) / 2; lo = c - 100; hi = c + 100; }
  const pos = (e: number) => `${((e - lo) / (hi - lo)) * 100}%`;

  return (
    <section aria-label="Рейтинг Elo" className="rounded-lg border border-line-subtle bg-bg-raised px-6 py-4">
      <h3 className="mb-1 font-display text-sm font-semibold">Рейтинг Elo</h3>
      <ul className="sr-only">{ratings.map((r) => <li key={r.model}>{r.label}: {Math.round(r.elo)}, партий {r.games}</li>)}</ul>
      <div aria-hidden className="relative mx-2 h-24">
        <div className="absolute inset-x-0 top-1/2 h-px bg-line-strong" />
        {[lo, (lo + hi) / 2, hi].map((t) => (
          <span key={t} className="absolute top-1/2 mt-2 -translate-x-1/2 font-mono text-[10px] text-fg-muted" style={{ left: pos(t) }}>{Math.round(t)}</span>
        ))}
        {ratings.map((r, i) => {
          const up = i % 2 === 0;
          const d = deltas?.[r.model];
          return (
            <motion.div key={r.model} className="absolute top-1/2 w-0" initial={false} animate={{ left: pos(r.elo) }}
              transition={{ type: 'spring', stiffness: 120, damping: 16 }}>
              <span className="absolute -ml-[6px] -mt-[6px] size-3 rounded-full bg-accent shadow-glow" />
              <div className={`absolute left-0 w-28 -translate-x-1/2 text-center ${up ? 'bottom-3' : 'top-6'}`}>
                <p className="truncate text-xs font-medium">{r.label.replace('Gemini ', '')}</p>
                <p className="font-mono text-xs text-accent"><Num value={r.elo} />
                  {d !== undefined && <motion.span key={d} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} className={`ml-1 ${d >= 0 ? 'text-ok' : 'text-err'}`}>{d >= 0 ? '+' : ''}{d.toFixed(1)}</motion.span>}
                </p>
              </div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
