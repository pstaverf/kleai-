'use client';
import { motion, useReducedMotion } from 'framer-motion';
import { MessageView } from '@/components/chat/MessageView';
import type { Side } from '@/lib/types';

export type Winner = Side | 'TIE' | null;

function Glyph({ letter, active }: { letter: string; active: boolean }) {
  const reduce = useReducedMotion();
  return (
    <svg width="36" height="36" viewBox="-18 -18 36 36" aria-hidden>
      <motion.circle r="15" fill="none" stroke="var(--color-accent-primary)" strokeWidth="1"
        animate={active && !reduce ? { r: [10, 16], opacity: [0.8, 0] } : { opacity: 0.25 }}
        transition={{ duration: 1.3, repeat: Infinity }} />
      <circle r="9" fill="var(--color-bg-overlay)" stroke="var(--color-accent-primary)" strokeWidth="1.4" />
      <text textAnchor="middle" dy="4" fontSize="11" fontWeight="700" fill="var(--color-accent-primary)" fontFamily="var(--font-display)">{letter}</text>
    </svg>
  );
}

export function NeuronCard({ side, text, error, streaming, winner, reveal }: {
  side: Side; text: string; error?: string; streaming: boolean; winner: Winner;
  reveal: { label: string; elo: number; delta: number } | null;
}) {
  const reduce = useReducedMotion();
  const won = winner === side;
  const tie = winner === 'TIE';
  const lost = winner !== null && !won && !tie;

  return (
    <motion.article
      aria-label={`Нейрон ${side}`}
      className={`flex min-h-48 min-w-0 flex-col overflow-hidden rounded-lg border bg-bg-raised ${won ? 'border-accent' : tie ? 'border-accent-alt' : 'border-line-subtle'}`}
      animate={
        won ? { opacity: 1, scale: reduce ? 1 : [1, 1.02, 1], boxShadow: ['0 0 0 rgba(46,242,224,0)', '0 0 48px rgba(46,242,224,0.7)', '0 0 22px rgba(46,242,224,0.35)'] }
        : tie ? { opacity: 1, boxShadow: '0 0 20px rgba(255,92,138,0.3)' }
        : lost ? { opacity: 0.5, boxShadow: '0 0 0 rgba(0,0,0,0)' }
        : { opacity: 1, boxShadow: '0 0 0 rgba(0,0,0,0)' }
      }
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
    >
      <header className="flex items-center gap-3 border-b border-line-subtle px-4 py-3">
        <Glyph letter={side} active={streaming} />
        <div className="min-w-0">
          <h3 className="font-display text-sm font-semibold">Нейрон {side}</h3>
          <p className="truncate text-xs text-fg-muted">
            {reveal ? `${reveal.label} · Elo ${reveal.elo.toFixed(0)} (${reveal.delta >= 0 ? '+' : ''}${reveal.delta.toFixed(1)})` : 'модель скрыта'}
          </p>
        </div>
      </header>
      <div className="max-h-[55dvh] min-h-0 flex-1 overflow-y-auto p-4">
        {!text && !streaming && !error ? (
          <p className="text-sm text-fg-muted">Ответ появится здесь.</p>
        ) : (
          <MessageView role="model" content={text} pending={streaming} onOpenFile={() => {}} />
        )}
        {error && <p role="alert" className="mt-3 text-sm text-err">{error}</p>}
      </div>
    </motion.article>
  );
}

/** Энергетическая связь между нейронами: импульсы бегут при генерации и «перетекают» к победителю. */
export function EnergyLink({ axis, state }: { axis: 'x' | 'y'; state: 'idle' | 'streaming' | 'toA' | 'toB' | 'tie' }) {
  const reduce = useReducedMotion();
  const dots = state === 'idle' ? 0 : 3;
  const horizontal = axis === 'x';
  const color = state === 'tie' ? 'var(--color-accent-secondary)' : 'var(--color-accent-primary)';
  return (
    <div aria-hidden className={`relative ${horizontal ? 'h-full min-h-48 w-full' : 'h-14 w-full'}`}>
      <div className="absolute" style={{
        background: state === 'idle' ? 'var(--color-border-strong)' : color,
        opacity: state === 'idle' ? 0.6 : 0.8, boxShadow: state === 'idle' ? 'none' : `0 0 12px ${color}`,
        ...(horizontal ? { left: 0, right: 0, top: '50%', height: 1 } : { top: 0, bottom: 0, left: '50%', width: 1 }),
      }} />
      {Array.from({ length: reduce ? 0 : dots }, (_, i) => {
        const forward = state === 'toB' ? true : state === 'toA' ? false : i % 2 === 0; // A→B / B→A
        const from = forward ? '0%' : '100%';
        const to = forward ? '100%' : '0%';
        const key = horizontal ? 'left' : 'top';
        return (
          <motion.span key={`${state}-${i}`} className="absolute size-1.5 rounded-full"
            style={{ background: color, boxShadow: `0 0 8px ${color}`, ...(horizontal ? { top: '50%', marginTop: -3 } : { left: '50%', marginLeft: -3 }) }}
            initial={{ [key]: from, opacity: 0 }}
            animate={state === 'tie' ? { [key]: ['45%', '55%', '45%'], opacity: 1 } : { [key]: [from, to], opacity: [0, 1, 0] }}
            transition={{ duration: state === 'streaming' ? 1.4 : 0.9, repeat: Infinity, delay: i * 0.3, ease: 'easeInOut' }} />
        );
      })}
    </div>
  );
}
