'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { useIsland } from '@/components/ui/island';
import { haptic } from '@/components/TelegramProvider';
import { EloScale } from './EloScale';
import { EnergyLink, NeuronCard, type Winner } from './Duel';
import { api } from '@/lib/client';
import { readSSE } from '@/lib/sse';
import type { ArenaEvent, ArenaRating, Side, VoteResult } from '@/lib/types';

type Phase = 'idle' | 'streaming' | 'ready' | 'revealed' | 'failed';
const SUGGESTIONS = ['Напиши функцию debounce на TypeScript', 'Страница с таймером Pomodoro (html+css+js)', 'Сортировка слиянием на Python с тестами'];

export function ArenaView() {
  const island = useIsland();
  const [phase, setPhase] = useState<Phase>('idle');
  const [prompt, setPrompt] = useState('');
  const [last, setLast] = useState('');
  const [texts, setTexts] = useState<Record<Side, string>>({ A: '', B: '' });
  const [sideErr, setSideErr] = useState<Partial<Record<Side, string>>>({});
  const [error, setError] = useState<string | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [voting, setVoting] = useState(false);
  const [result, setResult] = useState<VoteResult | null>(null);
  const [ratings, setRatings] = useState<ArenaRating[] | null>(null);
  const [ratingsErr, setRatingsErr] = useState(false);
  const [isLg, setIsLg] = useState(false);
  const bufs = useRef<Record<Side, string>>({ A: '', B: '' });
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    const m = matchMedia('(min-width: 1024px)');
    const f = () => setIsLg(m.matches);
    f(); m.addEventListener('change', f);
    return () => m.removeEventListener('change', f);
  }, []);

  const loadRatings = useCallback(() => {
    setRatingsErr(false);
    api<{ ratings: ArenaRating[] }>('/api/arena/ratings').then((d) => setRatings(d.ratings)).catch(() => setRatingsErr(true));
  }, []);
  useEffect(loadRatings, [loadRatings]);
  useEffect(() => () => abortRef.current?.abort(), []);

  const reset = () => {
    setPhase('idle'); setPrompt(''); setLast(''); setTexts({ A: '', B: '' }); bufs.current = { A: '', B: '' };
    setSideErr({}); setError(null); setToken(null); setResult(null);
  };

  const start = async (text: string) => {
    reset(); setPhase('streaming'); setLast(text);
    island.show({ state: 'thinking', label: 'Два нейрона думают…' });
    const ac = new AbortController();
    abortRef.current = ac;
    let raf = 0, gotToken = false, errMsg: string | null = null;
    const flush = () => { raf = 0; setTexts({ ...bufs.current }); };
    try {
      const res = await fetch('/api/arena/battle', {
        method: 'POST', signal: ac.signal, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ prompt: text }),
      });
      if (!res.ok || !res.body) {
        const d = await res.json().catch(() => ({}));
        throw new Error(d.message ?? 'Не удалось начать раунд');
      }
      for await (const ev of readSSE<ArenaEvent>(res)) {
        if (ev.type === 'delta') { bufs.current[ev.side] += ev.text; if (!raf) raf = requestAnimationFrame(flush); }
        else if (ev.type === 'side_error') { setSideErr((e) => ({ ...e, [ev.side]: ev.message })); errMsg ??= ev.message; }
        else if (ev.type === 'ready') { setToken(ev.token); gotToken = true; }
        else if (ev.type === 'error') errMsg = ev.message;
      }
    } catch (e) {
      if (!ac.signal.aborted) errMsg = e instanceof Error && e.message ? e.message : 'Связь с сетью потеряна.';
    } finally {
      if (raf) cancelAnimationFrame(raf);
      if (ac.signal.aborted) { reset(); island.hide(); return; }
      setTexts({ ...bufs.current });
      if (gotToken) { setPhase('ready'); island.show({ state: 'success', label: 'Ответы готовы — выбирай' }, 2000); haptic('light'); }
      else { setPhase('failed'); setError(errMsg ?? 'Раунд не состоялся.'); island.show({ state: 'error', label: errMsg ?? 'Раунд не состоялся' }, 5000); haptic('error'); }
    }
  };

  const vote = async (w: 'A' | 'B' | 'TIE') => {
    if (!token || voting) return;
    setVoting(true);
    try {
      const r = await api<VoteResult>('/api/arena/vote', { method: 'POST', json: { token, winner: w } });
      setResult(r); setRatings(r.ratings); setPhase('revealed'); haptic('success');
      island.show({ state: 'success', label: w === 'TIE' ? 'Ничья записана' : `Голос за нейрон ${w} записан` }, 1800);
    } catch (e) {
      const m = e instanceof Error ? e.message : 'Не удалось записать голос';
      setError(m); island.show({ state: 'error', label: m }, 5000); haptic('error');
    } finally { setVoting(false); }
  };

  const streaming = phase === 'streaming';
  const winner: Winner = result?.winner ?? null;
  const link = streaming ? 'streaming' : winner === 'A' ? 'toA' : winner === 'B' ? 'toB' : winner === 'TIE' ? 'tie' : 'idle';
  const canStart = (phase === 'idle' || phase === 'failed') && prompt.trim().length > 0;
  const editable = phase === 'idle' || phase === 'failed';
  const deltas = result ? { [result.a.model]: result.a.delta, [result.b.model]: result.b.delta } : null;

  return (
    <div className="flex min-h-0 flex-1 flex-col overflow-y-auto">
      <div className="space-y-4 pb-4">
        <EloScale ratings={ratings} error={ratingsErr} deltas={deltas} onRetry={loadRatings} />

        <div className="space-y-2 rounded-lg border border-line-strong bg-bg-raised p-2 shadow-raised">
          <label htmlFor="arena-prompt" className="sr-only">Задача для арены</label>
          <textarea id="arena-prompt" rows={2} maxLength={4000} readOnly={!editable}
            value={editable ? prompt : last} onChange={(e) => setPrompt(e.target.value)}
            placeholder="Дай задачу — два анонимных нейрона ответят, а ты выберешь лучшего…"
            className="block max-h-40 w-full resize-none bg-transparent px-2 py-2 text-[15px] text-fg placeholder:text-fg-muted focus:outline-none" />
          <div className="flex flex-wrap items-center gap-2">
            {phase === 'idle' && SUGGESTIONS.map((s) => (
              <button key={s} type="button" onClick={() => setPrompt(s)}
                className="min-h-touch rounded-pill border border-line-subtle px-3 text-xs text-fg-muted transition-colors hover:border-accent hover:text-fg">{s}</button>
            ))}
            <div className="ml-auto">
              {streaming
                ? <Button variant="danger" onClick={() => abortRef.current?.abort()}>Стоп</Button>
                : <Button disabled={!canStart} onClick={() => start(prompt.trim())}>Начать раунд</Button>}
            </div>
          </div>
        </div>

        <section aria-label="Дуэль нейронов" className="grid grid-cols-1 lg:grid-cols-[1fr_72px_1fr]">
          <NeuronCard side="A" text={texts.A} error={sideErr.A} streaming={streaming} winner={winner}
            reveal={result ? { label: result.a.label, elo: result.a.elo, delta: result.a.delta } : null} />
          <EnergyLink axis={isLg ? 'x' : 'y'} state={link} />
          <NeuronCard side="B" text={texts.B} error={sideErr.B} streaming={streaming} winner={winner}
            reveal={result ? { label: result.b.label, elo: result.b.elo, delta: result.b.delta } : null} />
        </section>
      </div>

      {(phase === 'ready' || phase === 'revealed' || phase === 'failed') && (
        <div className="sticky bottom-0 mt-auto border-t border-line-strong bg-bg-base py-3" role="group" aria-label="Голосование">
          {phase === 'ready' && (
            <div className="grid grid-cols-3 gap-2">
              <Button loading={voting} onClick={() => vote('A')} aria-label="Лучше ответ A">A лучше</Button>
              <Button variant="ghost" disabled={voting} onClick={() => vote('TIE')} aria-label="Ничья">Ничья</Button>
              <Button loading={voting} onClick={() => vote('B')} aria-label="Лучше ответ B">B лучше</Button>
            </div>
          )}
          {phase === 'revealed' && result && (
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm text-fg-muted" role="status">
                {result.winner === 'TIE' ? 'Ничья.' : `Победил нейрон ${result.winner}: ${result.winner === 'A' ? result.a.label : result.b.label}.`}
              </p>
              <Button onClick={reset}>Новый раунд</Button>
            </div>
          )}
          {phase === 'failed' && (
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p role="alert" className="text-sm text-err">{error}</p>
              <Button variant="ghost" onClick={() => start(last)}>Повторить раунд</Button>
            </div>
          )}
          {phase === 'ready' && error && <p role="alert" className="mt-2 text-sm text-err">{error}</p>}
        </div>
      )}
    </div>
  );
}
