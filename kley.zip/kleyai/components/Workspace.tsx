'use client';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Logo } from '@/components/Logo';
import { Button } from '@/components/ui/button';
import { Tabs } from '@/components/ui/tabs';
import { useIsland } from '@/components/ui/island';
import { haptic } from '@/components/TelegramProvider';
import { useTelegramBack } from '@/components/useTelegramButtons';
import { ChatPane } from '@/components/chat/ChatPane';
import { HistoryDrawer } from '@/components/chat/HistoryDrawer';
import { ArenaView } from '@/components/arena/ArenaView';
import { SidePanel, type PanelTab } from '@/components/panel/SidePanel';
import { api } from '@/lib/client';
import { readSSE } from '@/lib/sse';
import { extractFiles } from '@/lib/parse-code';
import { DEFAULT_MODEL, MODELS, type ModelId } from '@/lib/models';
import type { ChatFull, ChatSummary, GenFile, Me, Msg } from '@/lib/types';

type Edits = Record<string, { base: string; value: string }>;
const coerceModel = (m: string): ModelId => (MODELS.some((x) => x.id === m) ? (m as ModelId) : DEFAULT_MODEL);

export function Workspace({ me }: { me: Me }) {
  const island = useIsland();
  const [chats, setChats] = useState<ChatSummary[] | null>(null);
  const [chatsErr, setChatsErr] = useState(false);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [loadingChat, setLoadingChat] = useState(false);
  const [streaming, setStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [model, setModel] = useState<ModelId>(DEFAULT_MODEL);
  const [repo, setRepo] = useState<string | null>(null);
  const [branch, setBranch] = useState<string | null>(null);
  const [contextFiles, setContextFiles] = useState<string[]>([]);
  const [edits, setEdits] = useState<Edits>({});
  const [selected, setSelected] = useState<string | null>(null);
  const [view, setView] = useState<'chat' | 'panel'>('chat');
  const [panelTab, setPanelTab] = useState<PanelTab>('code');
  const [drawer, setDrawer] = useState(false);
  const [isLg, setIsLg] = useState(false);
  const [mode, setMode] = useState<'chat' | 'arena'>('chat');
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    const m = matchMedia('(min-width: 1024px)');
    const f = () => setIsLg(m.matches);
    f(); m.addEventListener('change', f);
    return () => m.removeEventListener('change', f);
  }, []);

  const refreshChats = useCallback(async () => {
    try { setChats((await api<{ chats: ChatSummary[] }>('/api/chats')).chats); setChatsErr(false); } catch { setChatsErr(true); }
  }, []);
  useEffect(() => { void refreshChats(); }, [refreshChats]);

  const generated = useMemo(() => extractFiles(messages.filter((m) => m.role === 'model').map((m) => m.content)), [messages]);
  const files: GenFile[] = useMemo(
    () => generated.map((f) => { const e = edits[f.path]; return e && e.base === f.content ? { ...f, content: e.value } : f; }),
    [generated, edits],
  );
  const onEdit = (p: string, v: string) => {
    const base = generated.find((f) => f.path === p)?.content;
    if (base !== undefined) setEdits((e) => ({ ...e, [p]: { base, value: v } }));
  };

  const resetState = () => { setMessages([]); setEdits({}); setSelected(null); setContextFiles([]); setError(null); };

  const newChat = () => {
    abortRef.current?.abort();
    setActiveId(null); resetState(); setRepo(null); setBranch(null); setView('chat'); setMode('chat');
  };

  const openChat = async (id: string) => {
    abortRef.current?.abort();
    setActiveId(id); resetState(); setLoadingChat(true); setView('chat'); setMode('chat');
    try {
      const d = await api<{ chat: ChatFull; messages: Msg[] }>(`/api/chats/${id}`);
      setMessages(d.messages); setModel(coerceModel(d.chat.model)); setRepo(d.chat.repoFull); setBranch(d.chat.branch);
    } catch (e) { setError(e instanceof Error ? e.message : 'Не удалось открыть чат'); }
    finally { setLoadingChat(false); }
  };

  const deleteChat = async (id: string) => {
    try { await api(`/api/chats/${id}`, { method: 'DELETE' }); } catch { /* список обновится ниже */ }
    if (id === activeId) newChat();
    void refreshChats();
  };

  const patch = (data: Record<string, unknown>) => {
    if (activeId) api(`/api/chats/${activeId}`, { method: 'PATCH', json: data }).catch(() => null);
  };
  const onModel = (m: ModelId) => { setModel(m); patch({ model: m }); };
  const onRepo = (r: string | null, b: string | null) => { setRepo(r); setBranch(b); patch({ repoFull: r, branch: b }); };

  const stop = () => abortRef.current?.abort();

  const send = async (text: string) => {
    setError(null);
    let chatId = activeId;
    if (!chatId) {
      try {
        const d = await api<{ chat: ChatFull }>('/api/chats', { method: 'POST', json: { model, repoFull: repo, branch } });
        chatId = d.chat.id; setActiveId(chatId);
      } catch (e) { setError(e instanceof Error ? e.message : 'Не удалось создать чат'); return; }
    }
    setMessages((m) => [...m, { id: `u${Date.now()}`, role: 'user', content: text }, { id: 'pending', role: 'model', content: '' }]);
    setStreaming(true);
    island.show({ state: 'thinking', label: 'Gemini думает…' });

    const ac = new AbortController();
    abortRef.current = ac;
    let buf = '', raf = 0, filesShown = false, outcome: 'done' | 'error' | 'aborted' = 'aborted';
    const flush = () => { raf = 0; const b = buf; setMessages((m) => m.map((x) => (x.id === 'pending' ? { ...x, content: b } : x))); };

    try {
      const res = await fetch(`/api/chats/${chatId}/stream`, {
        method: 'POST', signal: ac.signal, headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: text, model, contextFiles: repo ? contextFiles : [] }),
      });
      if (!res.ok || !res.body) {
        const d = await res.json().catch(() => ({}));
        throw new Error(d.message ?? 'Не удалось связаться с Gemini');
      }
      for await (const ev of readSSE(res)) {
        if (ev.type === 'delta') {
          buf += ev.text;
          if (!raf) raf = requestAnimationFrame(flush);
          if (!filesShown && /```[\w+-]*\s+file=/.test(buf)) { filesShown = true; island.show({ state: 'files', label: 'Пишу файлы…' }); }
        } else if (ev.type === 'error') {
          if (ev.code !== 'aborted') { outcome = 'error'; setError(ev.message); island.show({ state: 'error', label: ev.message }, 5000); haptic('error'); }
        } else if (ev.type === 'done') {
          outcome = 'done'; island.show({ state: 'success', label: 'Готово' }, 1500); haptic('success');
        }
      }
    } catch (e) {
      if (!(e instanceof DOMException && e.name === 'AbortError')) {
        outcome = 'error';
        const m = e instanceof Error && e.message ? e.message : 'Связь с сетью потеряна.';
        setError(m); island.show({ state: 'error', label: m }, 5000); haptic('error');
      }
    } finally {
      if (raf) cancelAnimationFrame(raf);
      const final = buf;
      setMessages((m) => (final ? m.map((x) => (x.id === 'pending' ? { ...x, id: `m${Date.now()}`, content: final } : x)) : m.filter((x) => x.id !== 'pending')));
      setStreaming(false);
      if (outcome === 'aborted') island.hide();
      void refreshChats();
    }
  };

  const openFile = (p: string) => { setSelected(p); setPanelTab('code'); setView('panel'); };

  useTelegramBack(drawer || view === 'panel', () => { if (drawer) setDrawer(false); else setView('chat'); });

  const title = chats?.find((c) => c.id === activeId)?.title ?? 'Новый чат';

  return (
    <main className="mx-auto flex h-full max-w-[1400px] flex-col gap-3 p-3">
      <header className="flex items-center gap-2">
        <button type="button" aria-label="История чатов" onClick={() => { haptic('light'); setDrawer(true); }}
          className="grid min-h-touch min-w-touch place-items-center rounded-pill border border-line-subtle bg-bg-raised text-fg hover:border-line-strong">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" aria-hidden><path d="M3 5h12M3 9h12M3 13h8" /></svg>
        </button>
        <div className="hidden sm:block"><Logo size={24} /></div>
        <h1 className="min-w-0 flex-1 truncate text-center font-display text-sm text-fg-muted">{mode === 'arena' ? 'Арена' : title}</h1>
        <Button variant="ghost" className="px-4 text-sm" onClick={async () => { await fetch('/api/auth/logout', { method: 'POST' }); location.reload(); }}>Выйти</Button>
      </header>

      <Tabs<'chat' | 'arena'> label="Режим" layoutId="mode-tab" value={mode} onChange={setMode}
        items={[{ id: 'chat', label: 'Чат' }, { id: 'arena', label: 'Арена' }]} />

      {mode === 'arena' ? <ArenaView /> : (<>
      <div className="grid min-h-0 flex-1 gap-3 lg:grid-cols-2">
        <section aria-label="Чат" className={`${view === 'chat' ? 'flex' : 'hidden'} min-h-0 flex-col lg:flex`}>
          <ChatPane messages={messages} loading={loadingChat} streaming={streaming} error={error} model={model}
            onModel={onModel} onSend={send} onStop={stop} onOpenFile={openFile} />
        </section>
        <section aria-label="Проект" className={`${view === 'panel' ? 'flex' : 'hidden'} min-h-0 flex-col lg:flex`}>
          <SidePanel tab={panelTab} onTab={setPanelTab} me={me} files={files} selected={selected} onSelect={setSelected} onEdit={onEdit}
            repo={repo} branch={branch} onRepo={onRepo} contextFiles={contextFiles} setContextFiles={setContextFiles}
            tgActive={isLg || view === 'panel'} />
        </section>
      </div>

      <nav className="lg:hidden" aria-label="Раздел">
        <Tabs<'chat' | 'panel'> label="Раздел" layoutId="view-tab" value={view} onChange={setView}
          items={[{ id: 'chat', label: 'Чат' }, { id: 'panel', label: files.length ? `Проект (${files.length})` : 'Проект' }]} />
      </nav>
      </>)}

      <HistoryDrawer open={drawer} chats={chats} error={chatsErr} activeId={activeId} onClose={() => setDrawer(false)}
        onPick={openChat} onNew={newChat} onDelete={deleteChat} onRetry={refreshChats} />
    </main>
  );
}
