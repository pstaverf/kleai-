'use client';
import { useEffect, type ReactNode } from 'react';

export const isTelegram = () => typeof window !== 'undefined' && 'Telegram' in window;

export function haptic(kind: 'light' | 'medium' | 'success' | 'error' = 'light') {
  try {
    const h = (window as any).Telegram?.WebApp?.HapticFeedback;
    if (!h) return;
    if (kind === 'success' || kind === 'error') h.notificationOccurred(kind);
    else h.impactOccurred(kind);
  } catch { /* вне Telegram — игнорируем */ }
}

/** Инициализация Mini App: SDK, expand, готовность, themeParams -> только акценты окружения. */
export function TelegramProvider({ children }: { children: ReactNode }) {
  useEffect(() => {
    (async () => {
      try {
        const sdk = await import('@telegram-apps/sdk');
        if (!(await sdk.isTMA('complete'))) return;
        sdk.init();
        if (sdk.miniApp.mountSync.isAvailable()) sdk.miniApp.mountSync();
        if (sdk.miniApp.ready.isAvailable()) sdk.miniApp.ready();
        // Фирменный фон шапки/низа независимо от темы Telegram
        const bg = getComputedStyle(document.documentElement).getPropertyValue('--color-bg-base').trim();
        if (sdk.miniApp.setHeaderColor.isAvailable()) sdk.miniApp.setHeaderColor(bg as `#${string}`);
        if (sdk.miniApp.setBottomBarColor.isAvailable()) sdk.miniApp.setBottomBarColor(bg as `#${string}`);
      } catch { /* обычный браузер */ }
    })();
  }, []);
  return <>{children}</>;
}

export async function getInitData(): Promise<string | null> {
  try {
    const sdk = await import('@telegram-apps/sdk');
    if (!(await sdk.isTMA('complete'))) return null;
    return sdk.retrieveRawInitData() ?? null;
  } catch { return null; }
}
