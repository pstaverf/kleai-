'use client';
import { useEffect, useRef } from 'react';

/* Telegram BackButton / MainButton. Вне Telegram — no-op. */

export function useTelegramBack(active: boolean, onBack: () => void) {
  const cb = useRef(onBack);
  cb.current = onBack;
  useEffect(() => {
    if (!active) return;
    let cancelled = false;
    let off: (() => void) | undefined;
    let sdk: typeof import('@telegram-apps/sdk') | undefined;
    (async () => {
      try {
        sdk = await import('@telegram-apps/sdk');
        if (cancelled || !(await sdk.isTMA('complete'))) return;
        const b = sdk.backButton;
        if (b.mount.isAvailable()) b.mount();
        if (b.show.isAvailable()) b.show();
        off = b.onClick(() => cb.current());
      } catch { /* не Mini App */ }
    })();
    return () => {
      cancelled = true;
      off?.();
      try { if (sdk?.backButton.hide.isAvailable()) sdk.backButton.hide(); } catch { /* ignore */ }
    };
  }, [active]);
}

export function useTelegramMain(p: { text: string; enabled: boolean; loading: boolean } | null, onClick: () => void) {
  const cb = useRef(onClick);
  cb.current = onClick;
  const visible = p !== null;
  const text = p?.text ?? '';
  const enabled = p?.enabled ?? false;
  const loading = p?.loading ?? false;

  useEffect(() => {
    if (!visible) return;
    let cancelled = false;
    let off: (() => void) | undefined;
    let sdk: typeof import('@telegram-apps/sdk') | undefined;
    (async () => {
      try {
        sdk = await import('@telegram-apps/sdk');
        if (cancelled || !(await sdk.isTMA('complete'))) return;
        const m = sdk.mainButton;
        if (m.mount.isAvailable()) m.mount();
        if (m.setParams.isAvailable()) m.setParams({ text, isVisible: true, isEnabled: enabled, isLoaderVisible: loading });
        off = m.onClick(() => cb.current());
      } catch { /* не Mini App */ }
    })();
    return () => {
      cancelled = true;
      off?.();
      try { if (sdk?.mainButton.setParams.isAvailable()) sdk.mainButton.setParams({ isVisible: false }); } catch { /* ignore */ }
    };
  }, [visible, text, enabled, loading]);
}
