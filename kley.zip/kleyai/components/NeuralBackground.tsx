'use client';
import { useEffect, useRef } from 'react';

interface N { x: number; y: number; vx: number; vy: number }

/** Интерактивная нейросеть на canvas. Мобильные/reduced-motion — облегчённо. */
export function NeuralBackground() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current!;
    const ctx = canvas.getContext('2d')!;
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const light = matchMedia('(max-width: 768px)').matches || 'Telegram' in window;
    const count = light ? 28 : 70;
    const link = light ? 110 : 150;
    let w = 0, h = 0, raf = 0;
    const mouse = { x: -9999, y: -9999 };
    const nodes: N[] = [];
    const css = (n: string) => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
    let accent = css('--color-accent-primary'), alt = css('--color-accent-secondary');

    const resize = () => {
      const dpr = Math.min(devicePixelRatio, 2);
      w = canvas.clientWidth; h = canvas.clientHeight;
      canvas.width = w * dpr; canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    for (let i = 0; i < count; i++)
      nodes.push({ x: Math.random() * w, y: Math.random() * h, vx: (Math.random() - 0.5) * 0.3, vy: (Math.random() - 0.5) * 0.3 });

    const draw = (t: number) => {
      accent = css('--color-accent-primary'); alt = css('--color-accent-secondary');
      ctx.clearRect(0, 0, w, h);
      for (const n of nodes) {
        if (!reduce) {
          n.x += n.vx; n.y += n.vy;
          if (n.x < 0 || n.x > w) n.vx *= -1;
          if (n.y < 0 || n.y > h) n.vy *= -1;
          const dx = n.x - mouse.x, dy = n.y - mouse.y, d = Math.hypot(dx, dy);
          if (d < 120) { n.x += (dx / d) * 1.2; n.y += (dy / d) * 1.2; }
        }
      }
      ctx.lineWidth = 1;
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const a = nodes[i]!, b = nodes[j]!, d = Math.hypot(a.x - b.x, a.y - b.y);
          if (d > link) continue;
          ctx.globalAlpha = (1 - d / link) * 0.35;
          ctx.strokeStyle = accent;
          ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
          // импульс вдоль связи
          if ((i * 31 + j * 17) % 11 === 0 && !reduce) {
            const p = ((t / 1800 + i * 0.13) % 1);
            ctx.globalAlpha = 0.9; ctx.fillStyle = alt;
            ctx.beginPath(); ctx.arc(a.x + (b.x - a.x) * p, a.y + (b.y - a.y) * p, 1.8, 0, 7); ctx.fill();
          }
        }
      }
      ctx.globalAlpha = 0.8; ctx.fillStyle = accent;
      for (const n of nodes) { ctx.beginPath(); ctx.arc(n.x, n.y, 1.8, 0, 7); ctx.fill(); }
      ctx.globalAlpha = 1;
      if (!reduce) raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);

    const move = (e: PointerEvent) => { const r = canvas.getBoundingClientRect(); mouse.x = e.clientX - r.left; mouse.y = e.clientY - r.top; };
    const leave = () => { mouse.x = mouse.y = -9999; };
    addEventListener('pointermove', move); addEventListener('pointerleave', leave); addEventListener('resize', resize);
    return () => {
      cancelAnimationFrame(raf);
      removeEventListener('pointermove', move); removeEventListener('pointerleave', leave); removeEventListener('resize', resize);
    };
  }, []);

  return <canvas ref={ref} aria-hidden className="pointer-events-none fixed inset-0 -z-10 h-full w-full" />;
}
