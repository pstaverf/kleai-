import type { GenFile } from './types';

export type Segment =
  | { type: 'text'; text: string }
  | { type: 'code'; lang: string; file: string | null; code: string; closed: boolean };

const SAFE_PATH = /^[\w./@+-]{1,300}$/;
export function safePath(p: string): string | null {
  return SAFE_PATH.test(p) && !p.includes('..') && !p.startsWith('/') ? p : null;
}

/** Разбор ответа модели: текст + блоки ```lang file=path. Работает и на частично пришедшем стриме. */
export function parseSegments(src: string): Segment[] {
  const out: Segment[] = [];
  let i = 0;
  while (i < src.length) {
    const open = src.indexOf('```', i);
    if (open === -1) { out.push({ type: 'text', text: src.slice(i) }); break; }
    if (open > i) out.push({ type: 'text', text: src.slice(i, open) });
    const nl = src.indexOf('\n', open);
    if (nl === -1) break; // info-строка ещё стримится
    const info = src.slice(open + 3, nl).trim();
    const close = src.indexOf('\n```', nl);
    const closed = close !== -1;
    const code = closed ? src.slice(nl + 1, Math.max(close, nl + 1)) : src.slice(nl + 1);
    const [lang = '', ...rest] = info.split(/\s+/);
    const fileTok = rest.find((t) => t.startsWith('file='));
    out.push({ type: 'code', lang, file: fileTok ? safePath(fileTok.slice(5)) : null, code, closed });
    i = closed ? close + 4 : src.length;
  }
  return out;
}

/** Все завершённые файлы из ответов модели; более поздняя версия перекрывает раннюю. */
export function extractFiles(texts: string[]): GenFile[] {
  const map = new Map<string, GenFile>();
  for (const t of texts)
    for (const s of parseSegments(t))
      if (s.type === 'code' && s.closed && s.file) map.set(s.file, { path: s.file, lang: s.lang, content: s.code });
  return [...map.values()];
}

export function langOf(path: string): string {
  const ext = path.split('.').pop()?.toLowerCase() ?? '';
  return ({ ts: 'typescript', tsx: 'typescript', js: 'javascript', jsx: 'javascript', mjs: 'javascript', json: 'json',
    html: 'html', css: 'css', md: 'markdown', py: 'python', go: 'go', rs: 'rust', yml: 'yaml', yaml: 'yaml', sh: 'shell', sql: 'sql' } as Record<string, string>)[ext] ?? 'plaintext';
}
