import type { StreamEvent } from './types';

export async function* readSSE<T = StreamEvent>(res: Response): AsyncGenerator<T> {
  const reader = res.body!.getReader();
  const dec = new TextDecoder();
  let buf = '';
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let idx: number;
    while ((idx = buf.indexOf('\n\n')) !== -1) {
      const chunk = buf.slice(0, idx);
      buf = buf.slice(idx + 2);
      if (chunk.startsWith('data: ')) yield JSON.parse(chunk.slice(6)) as T;
    }
  }
}
