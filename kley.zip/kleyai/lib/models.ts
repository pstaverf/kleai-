export const MODELS = [
  { id: 'gemini-2.5-pro', label: 'Gemini 2.5 Pro', hint: 'глубже и точнее' },
  { id: 'gemini-2.5-flash', label: 'Gemini 2.5 Flash', hint: 'быстрее' },
] as const;
export type ModelId = (typeof MODELS)[number]['id'];
export const MODEL_IDS = MODELS.map((m) => m.id) as [ModelId, ...ModelId[]];
export const DEFAULT_MODEL: ModelId = 'gemini-2.5-flash';
