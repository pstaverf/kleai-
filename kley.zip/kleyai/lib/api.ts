import { NextResponse } from 'next/server';
import { ZodError } from 'zod';
import type { User } from '@prisma/client';
import { currentUser } from './session';
import { decrypt } from './crypto';
import { octokitFor } from './github';

export class HttpError extends Error {
  constructor(public status: number, public code: string, message: string) { super(message); }
}

export async function requireUser(): Promise<User> {
  const u = await currentUser();
  if (!u) throw new HttpError(401, 'unauthorized', 'Нужен вход');
  return u;
}

export function githubFor(user: User) {
  if (!user.githubTokenEnc) throw new HttpError(403, 'github_not_connected', 'Сначала подключи GitHub');
  return octokitFor(decrypt(user.githubTokenEnc));
}

const err = (status: number, error: string, message: string) => NextResponse.json({ error, message }, { status });

export function toResponse(e: unknown): Response {
  if (e instanceof HttpError) return err(e.status, e.code, e.message);
  if (e instanceof ZodError) return err(400, 'bad_request', 'Некорректные данные запроса');
  const status = (e as { status?: number }).status;
  if (typeof status === 'number') {
    const message = (e as Error).message;
    if (status === 401) return err(403, 'github_token_invalid', 'GitHub-токен недействителен. Войди через GitHub заново.');
    if (status === 404) return err(404, 'not_found', 'Не найдено или нет доступа');
    if (status === 403 || status === 429) return err(429, 'github_rate_limit', 'GitHub ограничил запросы. Подожди немного.');
    if (status === 409 || status === 422) return err(422, 'github_rejected', message);
    return err(502, 'github_error', 'GitHub не ответил. Повтори позже.');
  }
  console.error(e);
  return err(500, 'internal', 'Внутренняя ошибка');
}

export function route<C = unknown>(fn: (req: Request, ctx: C) => Promise<Response>) {
  return async (req: Request, ctx: C): Promise<Response> => {
    try { return await fn(req, ctx); } catch (e) { return toResponse(e); }
  };
}
