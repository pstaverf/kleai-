import type { GenFile } from './types';

/** Собирает один самодостаточный HTML для sandbox-iframe: инлайнит локальные css/js, добавляет строгий CSP. */
export function buildPreview(files: GenFile[]): string | null {
  const html = files.find((f) => /(^|\/)index\.html$/.test(f.path)) ?? files.find((f) => f.path.endsWith('.html'));
  if (!html) return null;
  const dir = html.path.includes('/') ? html.path.slice(0, html.path.lastIndexOf('/') + 1) : '';
  const find = (href: string) => files.find((f) => f.path === dir + href.replace(/^\.\//, ''));

  let doc = html.content
    .replace(/<link\b[^>]*href=["']([^"']+)["'][^>]*>/gi, (m, h: string) => {
      const f = find(h);
      return f && f.path.endsWith('.css') ? `<style>${f.content}</style>` : m;
    })
    .replace(/<script\b([^>]*?)src=["']([^"']+)["']([^>]*)>\s*<\/script>/gi, (m, a: string, s: string, b: string) => {
      const f = find(s);
      return f ? `<script${a}${b}>${f.content.replace(/<\/script/gi, '<\\/script')}</script>` : m;
    });

  const csp =
    `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src data: blob:; font-src data:; media-src data: blob:">`;
  doc = /<head[^>]*>/i.test(doc) ? doc.replace(/<head[^>]*>/i, (m) => m + csp) : csp + doc;
  return doc;
}
