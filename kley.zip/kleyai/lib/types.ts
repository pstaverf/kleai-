export interface Me { id: string; name: string; username: string | null; avatarUrl: string | null; hasGithub: boolean; hasTelegram: boolean }
export interface ChatSummary { id: string; title: string; model: string; updatedAt: string }
export interface ChatFull extends ChatSummary { repoFull: string | null; branch: string | null }
export interface Msg { id: string; role: 'user' | 'model'; content: string }
export interface GenFile { path: string; lang: string; content: string }
export type StreamEvent =
  | { type: 'status'; state: 'thinking' }
  | { type: 'delta'; text: string }
  | { type: 'done'; messageId: string }
  | { type: 'error'; code: string; message: string };

export type Side = 'A' | 'B';
export type ArenaEvent =
  | { type: 'delta'; side: Side; text: string }
  | { type: 'side_done'; side: Side }
  | { type: 'side_error'; side: Side; message: string }
  | { type: 'ready'; token: string }
  | { type: 'error'; message: string };
export interface ArenaRating { model: string; label: string; elo: number; games: number }
export interface VoteResult {
  winner: 'A' | 'B' | 'TIE';
  a: { model: string; label: string; elo: number; delta: number };
  b: { model: string; label: string; elo: number; delta: number };
  ratings: ArenaRating[];
}
