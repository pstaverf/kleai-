export const K = 32;
export const START_ELO = 1000;

const expected = (ra: number, rb: number) => 1 / (1 + 10 ** ((rb - ra) / 400));

/** score — результат для A: 1 победа, 0.5 ничья, 0 поражение. */
export function eloUpdate(ra: number, rb: number, score: number): [number, number] {
  const ea = expected(ra, rb);
  return [ra + K * (score - ea), rb + K * (1 - score - (1 - ea))];
}
