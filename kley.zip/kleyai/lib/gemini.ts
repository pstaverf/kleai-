import { GoogleGenAI } from '@google/genai';
import { env } from './env';
import { SYSTEM_PROMPT } from './prompts';

export type GeminiErrorCode = 'rate_limit' | 'unavailable' | 'safety' | 'timeout' | 'aborted' | 'empty' | 'unknown';

const MESSAGES: Record<GeminiErrorCode, string> = {
  rate_limit: 'Сеть перегружена — сигнал не прошёл. Подожди несколько секунд и повтори.',
  unavailable: 'Gemini сейчас недоступен. Попробуй ещё раз через минуту.',
  safety: 'Gemini отклонил запрос фильтром безопасности. Переформулируй задачу.',
  timeout: 'Нейрон думал слишком долго. Попробуй ещё раз или выбери Flash.',
  aborted: 'Генерация остановлена.',
  empty: 'Gemini вернул пустой ответ. Уточни задачу и повтори.',
  unknown: 'Что-то пошло не так на стороне модели. Повтори запрос.',
};

export class GeminiError extends Error {
  constructor(public code: GeminiErrorCode) { super(MESSAGES[code]); }
}

let client: GoogleGenAI | null = null;
const ai = () => (client ??= new GoogleGenAI({ apiKey: env().GEMINI_API_KEY }));

const SAFETY_REASONS = new Set(['SAFETY', 'PROHIBITED_CONTENT', 'BLOCKLIST', 'SPII', 'IMAGE_SAFETY']);
const RETRYABLE = new Set<GeminiErrorCode>(['rate_limit', 'unavailable']);

function classify(e: unknown, user: AbortSignal, timeout: AbortSignal): GeminiError {
  if (e instanceof GeminiError) return e;
  if (user.aborted) return new GeminiError('aborted');
  if (timeout.aborted) return new GeminiError('timeout');
  const status = (e as { status?: number }).status;
  if (status === 429) return new GeminiError('rate_limit');
  if (status === 500 || status === 503 || status === 504) return new GeminiError('unavailable');
  console.error('gemini error', e);
  return new GeminiError('unknown');
}

export interface Turn { role: 'user' | 'model'; parts: { text: string }[] }

/** Стрим текста Gemini. Один авто-ретрай при 429/5xx, пока не пришёл ни один токен. */
export async function* streamGemini(opts: { model: string; contents: Turn[]; signal: AbortSignal }): AsyncGenerator<string> {
  for (let attempt = 0; attempt < 2; attempt++) {
    const timeout = AbortSignal.timeout(120_000);
    const signal = AbortSignal.any([opts.signal, timeout]);
    let yielded = false;
    try {
      const stream = await ai().models.generateContentStream({
        model: opts.model,
        contents: opts.contents,
        config: { systemInstruction: SYSTEM_PROMPT, temperature: 0.4, abortSignal: signal },
      });
      for await (const chunk of stream) {
        if (chunk.promptFeedback?.blockReason) throw new GeminiError('safety');
        const fr = chunk.candidates?.[0]?.finishReason;
        if (fr && SAFETY_REASONS.has(String(fr)) && !yielded) throw new GeminiError('safety');
        const t = chunk.text;
        if (t) { yielded = true; yield t; }
      }
      if (!yielded) throw new GeminiError('empty');
      return;
    } catch (e) {
      const err = classify(e, opts.signal, timeout);
      if (attempt === 0 && !yielded && RETRYABLE.has(err.code)) {
        await new Promise((r) => setTimeout(r, 1200));
        continue;
      }
      throw err;
    }
  }
}
