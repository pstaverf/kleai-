import { SignJWT, jwtVerify } from 'jose';
import { db } from './db';
import { env } from './env';
import { MODELS } from './models';
import { START_ELO } from './elo';
import type { ArenaRating } from './types';

const secret = () => new TextEncoder().encode(env().SESSION_SECRET);

export interface BattleClaims { bid: string; uid: string; a: string; b: string; p: string }

/** Подписанный токен раунда: клиент не видит, какая модель за A/B, и не может подделать пару. */
export const signBattle = (c: BattleClaims) =>
  new SignJWT({ ...c }).setProtectedHeader({ alg: 'HS256' }).setExpirationTime('30m').sign(secret());

export async function verifyBattle(token: string): Promise<BattleClaims> {
  const { payload } = await jwtVerify(token, secret());
  const { bid, uid, a, b, p } = payload as Record<string, unknown>;
  if ([bid, uid, a, b, p].some((v) => typeof v !== 'string')) throw new Error('bad token');
  return { bid, uid, a, b, p } as BattleClaims;
}

export const labelOf = (id: string) => MODELS.find((m) => m.id === id)?.label ?? id;

export async function ratingsWithDefaults(): Promise<ArenaRating[]> {
  const rows = await db.modelRating.findMany();
  return MODELS.map((m) => {
    const r = rows.find((x) => x.model === m.id);
    return { model: m.id, label: m.label, elo: r?.elo ?? START_ELO, games: r?.games ?? 0 };
  }).sort((x, y) => y.elo - x.elo);
}
