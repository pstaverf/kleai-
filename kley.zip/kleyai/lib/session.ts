import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';
import { env } from './env';
import { db } from './db';

const COOKIE = 'kley_session';
const secret = () => new TextEncoder().encode(env().SESSION_SECRET);

export async function createSession(userId: string) {
  const token = await new SignJWT({ uid: userId })
    .setProtectedHeader({ alg: 'HS256' })
    .setExpirationTime('30d')
    .sign(secret());
  (await cookies()).set(COOKIE, token, {
    httpOnly: true,
    secure: true,
    // Mini App открывается во фрейме Telegram Web → нужен SameSite=None
    sameSite: 'none',
    path: '/',
    maxAge: 60 * 60 * 24 * 30,
  });
}

export async function destroySession() {
  (await cookies()).delete(COOKIE);
}

export async function currentUserId(): Promise<string | null> {
  const token = (await cookies()).get(COOKIE)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret());
    return typeof payload.uid === 'string' ? payload.uid : null;
  } catch {
    return null;
  }
}

export async function currentUser() {
  const id = await currentUserId();
  return id ? db.user.findUnique({ where: { id } }) : null;
}
