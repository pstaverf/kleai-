import { z } from 'zod';

const schema = z.object({
  DATABASE_URL: z.string().url(),
  SESSION_SECRET: z.string().min(32),
  TOKEN_ENC_KEY: z.string().refine((s) => Buffer.from(s, 'base64').length === 32, 'Нужны 32 байта в base64'),
  APP_URL: z.string().url(),
  TELEGRAM_BOT_TOKEN: z.string().min(10),
  GITHUB_CLIENT_ID: z.string().min(1),
  GITHUB_CLIENT_SECRET: z.string().min(1),
  GEMINI_API_KEY: z.string().min(1),
});

let cached: z.infer<typeof schema> | null = null;
export function env() {
  if (!cached) cached = schema.parse(process.env);
  return cached;
}
