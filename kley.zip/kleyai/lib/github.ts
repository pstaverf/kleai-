import { Octokit } from 'octokit';
import { z } from 'zod';
import { env } from './env';

// Минимально возможный scope для OAuth App при работе с приватными репозиториями.
export const GITHUB_SCOPE = 'repo read:user';

export function githubAuthorizeUrl(state: string) {
  const u = new URL('https://github.com/login/oauth/authorize');
  u.searchParams.set('client_id', env().GITHUB_CLIENT_ID);
  u.searchParams.set('redirect_uri', `${env().APP_URL}/api/auth/github/callback`);
  u.searchParams.set('scope', GITHUB_SCOPE);
  u.searchParams.set('state', state);
  return u.toString();
}

const tokenSchema = z.object({ access_token: z.string() });

export async function exchangeCode(code: string): Promise<string> {
  const res = await fetch('https://github.com/login/oauth/access_token', {
    method: 'POST',
    headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
    body: JSON.stringify({
      client_id: env().GITHUB_CLIENT_ID,
      client_secret: env().GITHUB_CLIENT_SECRET,
      code,
      redirect_uri: `${env().APP_URL}/api/auth/github/callback`,
    }),
  });
  return tokenSchema.parse(await res.json()).access_token;
}

export const octokitFor = (token: string) => new Octokit({ auth: token });

// ---------- валидация ----------
export const repoSchema = z.string().regex(/^[\w.-]+\/[\w.-]+$/);
export const branchSchema = z.string().min(1).max(200).regex(/^[\w./-]+$/).refine((b) => !b.includes('..') && !b.endsWith('/'));
export const pathSchema = z.string().min(1).max(300).regex(/^[\w./@+-]+$/).refine((p) => !p.includes('..') && !p.startsWith('/'));
const split = (full: string) => { const [owner, repo] = full.split('/'); return { owner: owner!, repo: repo! }; };

// ---------- операции ----------
export async function listRepos(o: Octokit) {
  const { data } = await o.rest.repos.listForAuthenticatedUser({ per_page: 100, sort: 'pushed' });
  return data
    .filter((r) => r.permissions?.push)
    .map((r) => ({ fullName: r.full_name, defaultBranch: r.default_branch, private: r.private }));
}

export async function listBranches(o: Octokit, full: string) {
  const { data } = await o.rest.repos.listBranches({ ...split(full), per_page: 100 });
  return data.map((b) => b.name);
}

export async function defaultBranchOf(o: Octokit, full: string) {
  const { data } = await o.rest.repos.get(split(full));
  return data.default_branch;
}

const BINARY = /\.(png|jpe?g|gif|webp|ico|pdf|zip|gz|woff2?|ttf|otf|mp[34]|mov|lock)$/i;
const SKIP = /(^|\/)(node_modules|\.git|dist|build|\.next|coverage)\/|package-lock\.json$/;

export async function listTree(o: Octokit, full: string, branch: string) {
  const { data } = await o.rest.git.getTree({ ...split(full), tree_sha: branch, recursive: 'true' });
  const paths = data.tree
    .filter((t) => t.type === 'blob' && t.path && (t.size ?? 0) <= 100_000 && !BINARY.test(t.path) && !SKIP.test(t.path))
    .map((t) => t.path!)
    .slice(0, 3000);
  return { paths, truncated: data.truncated ?? false };
}

export async function readFile(o: Octokit, full: string, branch: string, path: string): Promise<string | null> {
  const { data } = await o.rest.repos.getContent({ ...split(full), path, ref: branch });
  if (Array.isArray(data) || data.type !== 'file' || !('content' in data) || data.size > 100_000) return null;
  return Buffer.from(data.content, 'base64').toString('utf8');
}

export async function createBranch(o: Octokit, full: string, from: string, name: string) {
  const s = split(full);
  const { data } = await o.rest.git.getRef({ ...s, ref: `heads/${from}` });
  await o.rest.git.createRef({ ...s, ref: `refs/heads/${name}`, sha: data.object.sha });
}

export async function commitFiles(
  o: Octokit, full: string, branch: string, message: string, files: { path: string; content: string }[],
) {
  const s = split(full);
  const ref = await o.rest.git.getRef({ ...s, ref: `heads/${branch}` });
  const parent = ref.data.object.sha;
  const parentCommit = await o.rest.git.getCommit({ ...s, commit_sha: parent });
  const tree = await o.rest.git.createTree({
    ...s,
    base_tree: parentCommit.data.tree.sha,
    tree: files.map((f) => ({ path: f.path, mode: '100644' as const, type: 'blob' as const, content: f.content })),
  });
  const commit = await o.rest.git.createCommit({ ...s, message, tree: tree.data.sha, parents: [parent] });
  await o.rest.git.updateRef({ ...s, ref: `heads/${branch}`, sha: commit.data.sha });
  return { sha: commit.data.sha, url: commit.data.html_url };
}

export async function openPullRequest(
  o: Octokit, full: string, head: string, base: string, title: string, body: string,
) {
  const { data } = await o.rest.pulls.create({ ...split(full), head, base, title, body });
  return { url: data.html_url, number: data.number };
}
