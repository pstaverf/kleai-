import { createHmac, timingSafeEqual } from 'node:crypto';
import { z } from 'zod';
import { env } from './env';

const userSchema = z.object({
  id: z.number(),
  first_name: z.string(),
  last_name: z.string().optional(),
  username: z.string().optional(),
  photo_url: z.string().url().optional(),
});
export type TgUser = z.infer<typeof userSchema>;

const MAX_AGE_SEC = 60 * 60 * 24;

/** Серверная валидация Telegram Mini App initData (HMAC-SHA256). */
export function validateInitData(raw: string): TgUser {
  const params = new URLSearchParams(raw);
  const hash = params.get('hash');
  if (!hash) throw new Error('no hash');
  params.delete('hash');

  const dcs = [...params.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}=${v}`)
    .join('\n');

  const secret = createHmac('sha256', 'WebAppData').update(env().TELEGRAM_BOT_TOKEN).digest();
  const expected = createHmac('sha256', secret).update(dcs).digest();
  const given = Buffer.from(hash, 'hex');
  if (given.length !== expected.length || !timingSafeEqual(given, expected)) throw new Error('bad signature');

  const authDate = Number(params.get('auth_date'));
  if (!authDate || Date.now() / 1000 - authDate > MAX_AGE_SEC) throw new Error('expired');

  return userSchema.parse(JSON.parse(params.get('user') ?? '{}'));
}
