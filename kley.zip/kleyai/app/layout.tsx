import type { Metadata, Viewport } from 'next';
import { Geist, Inter, JetBrains_Mono } from 'next/font/google';
import './globals.css';
import { IslandProvider } from '@/components/ui/island';
import { TelegramProvider } from '@/components/TelegramProvider';
import { NeuralBackground } from '@/components/NeuralBackground';

const geist = Geist({ subsets: ['latin', 'cyrillic'], variable: '--font-geist', display: 'swap' });
const inter = Inter({ subsets: ['latin', 'cyrillic'], variable: '--font-inter', display: 'swap' });
const mono = JetBrains_Mono({ subsets: ['latin', 'cyrillic'], variable: '--font-jb-mono', display: 'swap' });

export const metadata: Metadata = {
  title: 'KleyAI',
  description: 'Опиши задачу — нейросеть напишет код и закоммитит в GitHub.',
  icons: { icon: '/icon.svg' },
};
export const viewport: Viewport = { width: 'device-width', initialScale: 1, viewportFit: 'cover', themeColor: '#06060d' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru" data-theme="dark" className={`${geist.variable} ${inter.variable} ${mono.variable}`}>
      <body>
        <TelegramProvider>
          <IslandProvider>
            <NeuralBackground />
            {children}
          </IslandProvider>
        </TelegramProvider>
      </body>
    </html>
  );
}
