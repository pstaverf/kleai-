import { NextResponse } from 'next/server';
import { z } from 'zod';
import { route, requireUser, githubFor } from '@/lib/api';
import { branchSchema, createBranch, repoSchema } from '@/lib/github';

const body = z.object({ repo: repoSchema, from: branchSchema, name: branchSchema });

export const POST = route(async (req) => {
  const u = await requireUser();
  const b = body.parse(await req.json().catch(() => null));
  await createBranch(githubFor(u), b.repo, b.from, b.name);
  return NextResponse.json({ ok: true });
});
