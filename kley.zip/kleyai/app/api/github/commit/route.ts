import { NextResponse } from 'next/server';
import { z } from 'zod';
import { HttpError, route, requireUser, githubFor } from '@/lib/api';
import { branchSchema, commitFiles, defaultBranchOf, pathSchema, repoSchema } from '@/lib/github';

const body = z.object({
  repo: repoSchema,
  branch: branchSchema,
  message: z.string().trim().min(1).max(200),
  files: z.array(z.object({ path: pathSchema, content: z.string().max(500_000) })).min(1).max(50),
});

export const POST = route(async (req) => {
  const u = await requireUser();
  const b = body.parse(await req.json().catch(() => null));
  const o = githubFor(u);
  // Прямые коммиты в основную ветку запрещены: только отдельная ветка + PR.
  if ((await defaultBranchOf(o, b.repo)) === b.branch)
    throw new HttpError(400, 'default_branch_protected', 'Прямой коммит в основную ветку отключён. Создай новую ветку.');
  return NextResponse.json(await commitFiles(o, b.repo, b.branch, b.message, b.files));
});
