import { NextResponse } from 'next/server';
import { z } from 'zod';
import { route, requireUser, githubFor } from '@/lib/api';
import { branchSchema, defaultBranchOf, openPullRequest, repoSchema } from '@/lib/github';

const body = z.object({
  repo: repoSchema,
  head: branchSchema,
  title: z.string().trim().min(1).max(200),
  body: z.string().max(5000).default(''),
});

export const POST = route(async (req) => {
  const u = await requireUser();
  const b = body.parse(await req.json().catch(() => null));
  const o = githubFor(u);
  const base = await defaultBranchOf(o, b.repo);
  return NextResponse.json(await openPullRequest(o, b.repo, b.head, base, b.title, b.body || 'Создано в KleyAI'));
});
