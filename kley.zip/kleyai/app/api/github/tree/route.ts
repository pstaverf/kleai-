import { NextResponse } from 'next/server';
import { route, requireUser, githubFor } from '@/lib/api';
import { branchSchema, listTree, repoSchema } from '@/lib/github';

export const GET = route(async (req) => {
  const u = await requireUser();
  const q = new URL(req.url).searchParams;
  const repo = repoSchema.parse(q.get('repo'));
  const branch = branchSchema.parse(q.get('branch'));
  return NextResponse.json(await listTree(githubFor(u), repo, branch));
});
