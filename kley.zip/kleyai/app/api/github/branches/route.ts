import { NextResponse } from 'next/server';
import { route, requireUser, githubFor } from '@/lib/api';
import { listBranches, repoSchema } from '@/lib/github';

export const GET = route(async (req) => {
  const u = await requireUser();
  const repo = repoSchema.parse(new URL(req.url).searchParams.get('repo'));
  return NextResponse.json({ branches: await listBranches(githubFor(u), repo) });
});
