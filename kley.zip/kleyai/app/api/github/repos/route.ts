import { NextResponse } from 'next/server';
import { route, requireUser, githubFor } from '@/lib/api';
import { listRepos } from '@/lib/github';

export const GET = route(async () => {
  const u = await requireUser();
  return NextResponse.json({ repos: await listRepos(githubFor(u)) });
});
