import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { HttpError, route, requireUser } from '@/lib/api';
import { MODEL_IDS } from '@/lib/models';
import { branchSchema, repoSchema } from '@/lib/github';

type Ctx = { params: Promise<{ id: string }> };

async function own(id: string, userId: string) {
  const c = await db.chat.findFirst({ where: { id, userId }, select: { id: true } });
  if (!c) throw new HttpError(404, 'not_found', 'Чат не найден');
}

export const GET = route<Ctx>(async (_req, { params }) => {
  const u = await requireUser();
  const { id } = await params;
  const chat = await db.chat.findFirst({
    where: { id, userId: u.id },
    include: { messages: { orderBy: { createdAt: 'asc' }, select: { id: true, role: true, content: true } } },
  });
  if (!chat) throw new HttpError(404, 'not_found', 'Чат не найден');
  const { messages, ...meta } = chat;
  return NextResponse.json({ chat: meta, messages });
});

const patchBody = z.object({
  title: z.string().trim().min(1).max(80).optional(),
  model: z.enum(MODEL_IDS).optional(),
  repoFull: repoSchema.nullable().optional(),
  branch: branchSchema.nullable().optional(),
});

export const PATCH = route<Ctx>(async (req, { params }) => {
  const u = await requireUser();
  const { id } = await params;
  await own(id, u.id);
  const data = patchBody.parse(await req.json());
  await db.chat.update({ where: { id }, data });
  return NextResponse.json({ ok: true });
});

export const DELETE = route<Ctx>(async (_req, { params }) => {
  const u = await requireUser();
  const { id } = await params;
  await own(id, u.id);
  await db.chat.delete({ where: { id } });
  return NextResponse.json({ ok: true });
});
