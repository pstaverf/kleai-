import { z } from 'zod';
import type { User } from '@prisma/client';
import { db } from '@/lib/db';
import { HttpError, route, requireUser, githubFor } from '@/lib/api';
import { GeminiError, streamGemini, type Turn } from '@/lib/gemini';
import { MODEL_IDS } from '@/lib/models';
import { pathSchema, readFile } from '@/lib/github';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

type Ctx = { params: Promise<{ id: string }> };

const body = z.object({
  content: z.string().trim().min(1).max(20_000),
  model: z.enum(MODEL_IDS),
  contextFiles: z.array(pathSchema).max(20).default([]),
});

async function repoContext(user: User, repo: string | null, branch: string | null, paths: string[]) {
  if (!repo || !branch || !paths.length) return '';
  const o = githubFor(user);
  const parts: string[] = [];
  let total = 0;
  for (const p of paths) {
    const c = await readFile(o, repo, branch, p).catch(() => null);
    if (c == null) continue;
    if (total + c.length > 200_000) break;
    total += c.length;
    parts.push(`### ${p}\n\`\`\`\n${c}\n\`\`\``);
  }
  return parts.length ? `Контекст репозитория ${repo}@${branch}:\n\n${parts.join('\n\n')}\n\n---\n` : '';
}

export const POST = route<Ctx>(async (req, { params }) => {
  const user = await requireUser();
  const { id } = await params;
  const b = body.parse(await req.json().catch(() => null));

  const chat = await db.chat.findFirst({ where: { id, userId: user.id } });
  if (!chat) throw new HttpError(404, 'not_found', 'Чат не найден');

  await db.message.create({ data: { chatId: id, role: 'user', content: b.content } });
  await db.chat.update({
    where: { id },
    data: { model: b.model, ...(chat.title === 'Новый чат' ? { title: b.content.replace(/\s+/g, ' ').slice(0, 48) } : {}) },
  });

  const history = (await db.message.findMany({ where: { chatId: id }, orderBy: { createdAt: 'desc' }, take: 40 })).reverse();
  const contents: Turn[] = history.map((m) => ({ role: m.role === 'user' ? 'user' : 'model', parts: [{ text: m.content }] }));
  const ctx = await repoContext(user, chat.repoFull, chat.branch, b.contextFiles).catch(() => '');
  const last = contents[contents.length - 1];
  if (last && ctx) last.parts = [{ text: ctx + b.content }];

  const enc = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const send = (o: unknown) => { try { controller.enqueue(enc.encode(`data: ${JSON.stringify(o)}\n\n`)); } catch { /* клиент ушёл */ } };
      let full = '';
      const save = () => db.message.create({ data: { chatId: id, role: 'model', content: full } });
      try {
        send({ type: 'status', state: 'thinking' });
        for await (const t of streamGemini({ model: b.model, contents, signal: req.signal })) {
          full += t;
          send({ type: 'delta', text: t });
        }
        const saved = await save();
        send({ type: 'done', messageId: saved.id });
      } catch (e) {
        const ge = e instanceof GeminiError ? e : new GeminiError('unknown');
        if (full) await save().catch(() => null); // сохраняем частичный ответ (в т.ч. при остановке)
        send({ type: 'error', code: ge.code, message: ge.message });
      } finally {
        try { controller.close(); } catch { /* уже закрыт */ }
      }
    },
  });

  return new Response(stream, {
    headers: { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' },
  });
});
