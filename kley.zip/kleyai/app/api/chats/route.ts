import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { route, requireUser } from '@/lib/api';
import { DEFAULT_MODEL, MODEL_IDS } from '@/lib/models';
import { branchSchema, repoSchema } from '@/lib/github';

export const GET = route(async () => {
  const u = await requireUser();
  const chats = await db.chat.findMany({
    where: { userId: u.id }, orderBy: { updatedAt: 'desc' }, take: 100,
    select: { id: true, title: true, model: true, updatedAt: true },
  });
  return NextResponse.json({ chats });
});

const createBody = z.object({
  model: z.enum(MODEL_IDS).optional(),
  repoFull: repoSchema.nullable().optional(),
  branch: branchSchema.nullable().optional(),
});

export const POST = route(async (req) => {
  const u = await requireUser();
  const b = createBody.parse(await req.json().catch(() => ({})));
  const chat = await db.chat.create({
    data: { userId: u.id, model: b.model ?? DEFAULT_MODEL, repoFull: b.repoFull ?? null, branch: b.branch ?? null },
    select: { id: true, title: true, model: true, updatedAt: true, repoFull: true, branch: true },
  });
  return NextResponse.json({ chat });
});
