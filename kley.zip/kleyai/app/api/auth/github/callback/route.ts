import { NextResponse, type NextRequest } from 'next/server';
import { cookies } from 'next/headers';
import { db } from '@/lib/db';
import { env } from '@/lib/env';
import { encrypt } from '@/lib/crypto';
import { exchangeCode, octokitFor } from '@/lib/github';
import { createSession, currentUserId } from '@/lib/session';

export async function GET(req: NextRequest) {
  const code = req.nextUrl.searchParams.get('code');
  const state = req.nextUrl.searchParams.get('state');
  const jar = await cookies();
  const saved = jar.get('kley_oauth_state')?.value;
  jar.delete('kley_oauth_state');

  const fail = (reason: string) => NextResponse.redirect(`${env().APP_URL}/?auth_error=${reason}`);
  if (!code || !state || !saved || state !== saved) return fail('state');

  try {
    const token = await exchangeCode(code);
    const { data: gh } = await octokitFor(token).rest.users.getAuthenticated();
    const data = {
      githubId: gh.id,
      name: gh.name ?? gh.login,
      username: gh.login,
      avatarUrl: gh.avatar_url,
      githubTokenEnc: encrypt(token),
    };

    const existingId = await currentUserId();
    const user = existingId
      ? await db.user.update({ where: { id: existingId }, data }).catch(() => null)
      : null;
    const final =
      user ??
      (await db.user.upsert({ where: { githubId: gh.id }, create: data, update: data }));

    await createSession(final.id);
    return NextResponse.redirect(`${env().APP_URL}/`);
  } catch {
    return fail('github');
  }
}
