import { NextResponse } from 'next/server';
import { randomBytes } from 'node:crypto';
import { cookies } from 'next/headers';
import { githubAuthorizeUrl } from '@/lib/github';

export async function GET() {
  const state = randomBytes(16).toString('hex');
  (await cookies()).set('kley_oauth_state', state, {
    httpOnly: true, secure: true, sameSite: 'lax', path: '/', maxAge: 600,
  });
  return NextResponse.redirect(githubAuthorizeUrl(state));
}
