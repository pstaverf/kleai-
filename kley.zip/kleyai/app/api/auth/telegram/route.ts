import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { validateInitData } from '@/lib/telegram';
import { createSession, currentUserId } from '@/lib/session';

const body = z.object({ initData: z.string().min(1).max(4096) });

export async function POST(req: Request) {
  const parsed = body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: 'bad_request' }, { status: 400 });

  let tg;
  try {
    tg = validateInitData(parsed.data.initData);
  } catch {
    return NextResponse.json({ error: 'invalid_init_data' }, { status: 401 });
  }

  const name = [tg.first_name, tg.last_name].filter(Boolean).join(' ');
  const data = { name, username: tg.username ?? null, avatarUrl: tg.photo_url ?? null };
  const telegramId = BigInt(tg.id);

  // Если уже есть сессия (например, вход через GitHub) — привязываем Telegram к тому же аккаунту.
  const existingId = await currentUserId();
  const user = existingId
    ? await db.user.update({ where: { id: existingId }, data: { telegramId, ...data } }).catch(() => null)
    : null;
  const final =
    user ??
    (await db.user.upsert({ where: { telegramId }, create: { telegramId, ...data }, update: data }));

  await createSession(final.id);
  return NextResponse.json({ ok: true });
}
