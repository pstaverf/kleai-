import { NextResponse } from 'next/server';
import { currentUser } from '@/lib/session';

export async function GET() {
  const u = await currentUser();
  if (!u) return NextResponse.json({ user: null });
  return NextResponse.json({
    user: {
      id: u.id,
      name: u.name,
      username: u.username,
      avatarUrl: u.avatarUrl,
      hasGithub: u.githubId !== null,
      hasTelegram: u.telegramId !== null,
    },
  });
}
