import { NextResponse } from 'next/server';
import { route, requireUser } from '@/lib/api';
import { ratingsWithDefaults } from '@/lib/arena';

export const GET = route(async () => {
  await requireUser();
  return NextResponse.json({ ratings: await ratingsWithDefaults() });
});
