import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { HttpError, route, requireUser } from '@/lib/api';
import { labelOf, ratingsWithDefaults, verifyBattle } from '@/lib/arena';
import { eloUpdate } from '@/lib/elo';

const body = z.object({ token: z.string().max(8000), winner: z.enum(['A', 'B', 'TIE']) });

export const POST = route(async (req) => {
  const user = await requireUser();
  const b = body.parse(await req.json().catch(() => null));
  const t = await verifyBattle(b.token).catch(() => { throw new HttpError(400, 'bad_token', 'Раунд устарел. Начни новый.'); });
  if (t.uid !== user.id) throw new HttpError(403, 'forbidden', 'Этот раунд принадлежит другому аккаунту');

  const score = b.winner === 'A' ? 1 : b.winner === 'B' ? 0 : 0.5;

  const out = await db.$transaction(async (tx) => {
    try {
      await tx.arenaVote.create({ data: { userId: user.id, battleId: t.bid, prompt: t.p, modelA: t.a, modelB: t.b, winner: b.winner } });
    } catch (e) {
      if ((e as { code?: string }).code === 'P2002') throw new HttpError(409, 'already_voted', 'В этом раунде голос уже записан.');
      throw e;
    }
    const ra = await tx.modelRating.upsert({ where: { model: t.a }, create: { model: t.a }, update: {} });
    const rb = await tx.modelRating.upsert({ where: { model: t.b }, create: { model: t.b }, update: {} });
    const [na, nb] = eloUpdate(ra.elo, rb.elo, score);
    await tx.modelRating.update({ where: { model: t.a }, data: { elo: na, games: { increment: 1 } } });
    await tx.modelRating.update({ where: { model: t.b }, data: { elo: nb, games: { increment: 1 } } });
    return { a: { model: t.a, label: labelOf(t.a), elo: na, delta: na - ra.elo }, b: { model: t.b, label: labelOf(t.b), elo: nb, delta: nb - rb.elo } };
  }, { isolationLevel: 'Serializable' });

  return NextResponse.json({ winner: b.winner, ...out, ratings: await ratingsWithDefaults() });
});
