import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { route, requireUser } from '@/lib/api';
import { GeminiError, streamGemini } from '@/lib/gemini';
import { MODELS } from '@/lib/models';
import { signBattle } from '@/lib/arena';
import type { Side } from '@/lib/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const body = z.object({ prompt: z.string().trim().min(1).max(4000) });

export const POST = route(async (req) => {
  const user = await requireUser();
  const { prompt } = body.parse(await req.json().catch(() => null));

  // Две разные случайные модели, случайный порядок A/B.
  const [a, b] = [...MODELS].sort(() => Math.random() - 0.5).slice(0, 2).map((m) => m.id);
  if (!a || !b) throw new Error('Нужно минимум две модели в конфиге');

  const enc = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const send = (o: unknown) => { try { controller.enqueue(enc.encode(`data: ${JSON.stringify(o)}\n\n`)); } catch { /* клиент ушёл */ } };
      const contents = [{ role: 'user' as const, parts: [{ text: prompt }] }];
      // Идентичность модели в потоке не раскрывается — только сторона A/B.
      const run = async (side: Side, model: string) => {
        try {
          for await (const t of streamGemini({ model, contents, signal: req.signal })) send({ type: 'delta', side, text: t });
          send({ type: 'side_done', side });
          return true;
        } catch (e) {
          const ge = e instanceof GeminiError ? e : new GeminiError('unknown');
          if (ge.code !== 'aborted') send({ type: 'side_error', side, message: ge.message });
          return false;
        }
      };
      try {
        const [okA, okB] = await Promise.all([run('A', a), run('B', b)]);
        if (okA && okB) send({ type: 'ready', token: await signBattle({ bid: randomUUID(), uid: user.id, a, b, p: prompt }) });
        else send({ type: 'error', message: 'Раунд не состоялся: один из нейронов не ответил. Начни заново.' });
      } finally {
        try { controller.close(); } catch { /* уже закрыт */ }
      }
    },
  });

  return new Response(stream, {
    headers: { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' },
  });
});
