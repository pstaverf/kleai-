#!/usr/bin/env node
'use strict';

// Точка входа для запуска проекта (Wispbyte / Pterodactyl / VPS / локально):
//   node index.js          — production-запуск (автоматически соберёт проект при первом старте)
//   node index.js --build  — принудительная пересборка перед запуском
//   node index.js --dev    — режим разработки (next dev)

const fs = require('node:fs');
const path = require('node:path');
const { spawnSync, spawn } = require('node:child_process');

let rootDir = __dirname;
if (
  !fs.existsSync(path.join(rootDir, 'server.js')) &&
  !fs.existsSync(path.join(rootDir, 'package.json')) &&
  fs.existsSync(path.join(rootDir, 'kleyai')) &&
  (fs.existsSync(path.join(rootDir, 'kleyai', 'server.js')) ||
    fs.existsSync(path.join(rootDir, 'kleyai', 'package.json')))
) {
  rootDir = path.join(rootDir, 'kleyai');
}
process.chdir(rootDir);

// Мини-загрузчик .env без внешних зависимостей (непустые переменные панели хостинга приоритетнее)
function loadEnvFile(filePath) {
  if (!fs.existsSync(filePath)) return;
  const raw = fs.readFileSync(filePath, 'utf8');
  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const m = trimmed.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
    if (!m) continue;
    const key = m[1];
    let val = m[2].trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      const quote = val[0];
      val = val.slice(1, -1);
      if (quote === '"') val = val.replace(/\\n/g, '\n').replace(/\\"/g, '"');
    } else {
      const hashIdx = val.indexOf(' #');
      if (hashIdx !== -1) val = val.slice(0, hashIdx).trim();
    }
    if (val !== '' && (process.env[key] === undefined || process.env[key] === '')) {
      process.env[key] = val;
    }
  }
}

loadEnvFile(path.join(rootDir, '.env'));
if (rootDir !== __dirname) loadEnvFile(path.join(__dirname, '.env'));

const args = new Set(process.argv.slice(2));
const isDev = args.has('--dev') || process.env.KLEY_DEV === '1';
const forceBuild = args.has('--build') || process.env.FORCE_BUILD === '1';

const port = String(process.env.PORT || process.env.SERVER_PORT || '3000');
const hostname = process.env.HOSTNAME || '0.0.0.0';
process.env.PORT = port;
process.env.HOSTNAME = hostname;

// Режим готового бандла deploy/ (рядом с index.js уже лежит standalone server.js)
const standaloneRootServer = path.join(rootDir, 'server.js');
if (fs.existsSync(standaloneRootServer) && !isDev && !forceBuild) {
  process.env.NODE_ENV = 'production';
  console.log(`[KleyAI] Запуск standalone-сервера на http://${hostname}:${port}`);
  require(standaloneRootServer);
  return;
}

const PLACEHOLDER_DB_URL = 'postgresql://x:x@localhost:5432/x';

function run(cmd, cmdArgs, extraEnv = {}) {
  const res = spawnSync(cmd, cmdArgs, {
    cwd: rootDir,
    stdio: 'inherit',
    env: { ...process.env, ...extraEnv },
    shell: process.platform === 'win32' && cmd.endsWith('.cmd'),
  });
  if (res.error) {
    console.error(`[KleyAI] Ошибка запуска ${cmd}:`, res.error.message);
    process.exit(1);
  }
  if (res.status !== 0) {
    process.exit(res.status ?? 1);
  }
}

function hasPkg(rel) {
  return fs.existsSync(path.join(rootDir, 'node_modules', ...rel.split('/')));
}

function ensureDependencies(needBuildDeps) {
  const missingCore = !hasPkg('next/dist/bin/next');
  const missingBuild =
    needBuildDeps &&
    (!hasPkg('prisma/build/index.js') || !hasPkg('tailwindcss/package.json') || !hasPkg('postcss/package.json'));

  if (missingCore || missingBuild) {
    console.log('[KleyAI] Установка зависимостей (npm install)...');
    const npmCmd = process.platform === 'win32' ? 'npm.cmd' : 'npm';
    run(npmCmd, ['install', '--include=dev', '--no-audit', '--no-fund'], { NODE_ENV: 'development' });
  }
}

function ensureTokens(force = false) {
  const tokensScript = path.join(rootDir, 'scripts', 'build-tokens.mjs');
  const tokensOut = path.join(rootDir, 'app', 'tokens.css');
  if (fs.existsSync(tokensScript) && (force || !fs.existsSync(tokensOut))) {
    console.log('[KleyAI] Генерация дизайн-токенов (app/tokens.css)...');
    run(process.execPath, [tokensScript]);
  }
}

function ensurePrismaClient(force = false) {
  const generatedClient = path.join(rootDir, 'node_modules', '.prisma', 'client', 'default.js');
  const prismaCli = path.join(rootDir, 'node_modules', 'prisma', 'build', 'index.js');
  if (fs.existsSync(prismaCli) && (force || !fs.existsSync(generatedClient))) {
    console.log('[KleyAI] Генерация Prisma Client...');
    run(process.execPath, [prismaCli, 'generate'], {
      DATABASE_URL: process.env.DATABASE_URL || PLACEHOLDER_DB_URL,
    });
  }
}

function maybeMigrate() {
  if (process.env.AUTO_MIGRATE === '1' || process.env.AUTO_MIGRATE === 'true') {
    const prismaCli = path.join(rootDir, 'node_modules', 'prisma', 'build', 'index.js');
    if (fs.existsSync(prismaCli) && process.env.DATABASE_URL) {
      console.log('[KleyAI] Применение миграций БД (prisma migrate deploy)...');
      run(process.execPath, [prismaCli, 'migrate', 'deploy']);
    }
  }
}

if (isDev) {
  ensureDependencies(true);
  ensureTokens(true);
  ensurePrismaClient(false);
  maybeMigrate();
  const nextBin = path.join(rootDir, 'node_modules', 'next', 'dist', 'bin', 'next');
  console.log(`[KleyAI] Запуск dev-сервера на http://${hostname}:${port}`);
  const child = spawn(process.execPath, [nextBin, 'dev', '-H', hostname, '-p', port], {
    cwd: rootDir,
    stdio: 'inherit',
    env: { ...process.env, NODE_ENV: 'development' },
  });
  child.on('exit', (code) => process.exit(code ?? 0));
  return;
}

const standaloneDir = path.join(rootDir, '.next', 'standalone');
const standaloneServer = path.join(standaloneDir, 'server.js');
const needBuild = forceBuild || !fs.existsSync(standaloneServer);

ensureDependencies(needBuild);

function copyIfExists(fromRel, toFull) {
  const src = path.join(rootDir, fromRel);
  if (fs.existsSync(src)) {
    fs.cpSync(src, toFull, { recursive: true, force: true });
  }
}

function syncStandaloneAssets(full = false) {
  if (!fs.existsSync(standaloneDir)) return;
  if (full || !fs.existsSync(path.join(standaloneDir, '.next', 'static'))) {
    copyIfExists(path.join('.next', 'static'), path.join(standaloneDir, '.next', 'static'));
  }
  if (full || !fs.existsSync(path.join(standaloneDir, 'public'))) {
    copyIfExists('public', path.join(standaloneDir, 'public'));
  }
  if (full || !fs.existsSync(path.join(standaloneDir, 'node_modules', '.prisma'))) {
    copyIfExists(path.join('node_modules', '.prisma'), path.join(standaloneDir, 'node_modules', '.prisma'));
    copyIfExists(
      path.join('node_modules', '@prisma', 'client'),
      path.join(standaloneDir, 'node_modules', '@prisma', 'client')
    );
  }
}

if (needBuild) {
  ensureTokens(true);
  ensurePrismaClient(forceBuild);
  console.log('[KleyAI] Сборка production-версии (next build)...');
  const nextBin = path.join(rootDir, 'node_modules', 'next', 'dist', 'bin', 'next');
  run(process.execPath, [nextBin, 'build'], {
    NODE_ENV: 'production',
    NEXT_TELEMETRY_DISABLED: '1',
    DATABASE_URL: process.env.DATABASE_URL || PLACEHOLDER_DB_URL,
  });
  syncStandaloneAssets(true);
} else {
  syncStandaloneAssets(false);
}

maybeMigrate();

process.env.NODE_ENV = 'production';
console.log(`[KleyAI] Запуск сервера на http://${hostname}:${port}`);
require(standaloneServer);
